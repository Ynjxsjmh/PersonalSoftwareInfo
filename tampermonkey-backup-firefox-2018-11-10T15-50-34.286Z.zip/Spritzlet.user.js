// ==UserScript==
// @name         Spritzlet
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @include        *
// @grant        none
// ==/UserScript==

(function() {
    
})();