// ==UserScript==
// @name         网易云歌词展开
// @version      0.1
// @description  替你点 展开
// @author       Ynjxsjmh
// @match        *://music.163.com/*
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function() {
    //for(var t = Date.now();Date.now() - t <= 500;);  // 点完第一个过 0.5s 后再点第二个
    $("#flag_ctrl").click();

    $("#flag_more").display.remove();
})();