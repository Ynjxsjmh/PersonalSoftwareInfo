// ==UserScript==
// @name               iciba划词翻译
// @namespace          noe132.com
// @author             noe132
// @include            http://*
// @include            https://*
// @exclude            http://www.iciba.com*
// @grant              GM_xmlhttpRequest
// @grant              GM_addStyle
// @grant              GM_getValue
// @grant              GM_setValue
// @grant              GM_registerMenuCommand
// @icon               http://tb.himg.baidu.com/sys/portrait/item/d4346e6f65313332ac06
// @require            https://cdn.bootcss.com/es6-promise/4.1.1/es6-promise.auto.min.js
// @version            3.3.1
// @supportURL         http://tieba.baidu.com/f?kw=firefox
// @description iciba翻译
// ==/UserScript==


/* ------------------ changelog -------------------
 * update INFO:
 * update 2017/05/09 : bug fix
 * update 2017/04/20 : 添加鼠标悬浮触发查词
 * update 2017/04/19 : 终于搞明白怎么定位了
 * update 2017/04/18 : 添加最大选择数设置和默认行为设置，优化样式
 * update 2017/04/12 : 添加了百度翻译谷歌翻译按钮
 * update 2017/04/12 : 搞了个字符串压缩~解压字符串速度还可以
 * update 2017/04/11 : bug fix，重写鼠标事件定位方法
 * update 2017/03/24 : 添加鼠标事件10ms延迟
 * update 2017/03/24 : 用babel翻译async function，可以支持到chrome33
 * update 2017/03/23 : 使用百度翻译API，iciba的程序员不更新api
 * update 2016/12/23 : trim查询字符串，更新版本号到3
 * update 2016/09/23 : mouseClick只能左键触发
 * update 2016/08/19 : 不知为何connect属性未加上
 * update 2016/05/30 : 样式修改
 * update 2016/05/03 : 解释处理修改
 * update 2016/05/02 : 样式修改
 * update 2016/05/01 : 样式修改
 * update 2016/04/22 : 老版本浏览器兼容性修复
 * update 2016/04/17 : 样式修改
 * update 2016/04/17 : 重写
 * update 2016/04/09 : 样式小改
 * update 2016/03/27 : 紧急修复。。。
 * update 2016/03/16 : 样式修正
 * update 2016/03/05 : 样式小改
 * update 2015/07/31 : 貌似之前的wordpress判断不太给力，干脆带wp-admin的都干掉
 * update 2015/07/12 : 去除wp-admin/post.php页面，防止wordpress编辑文章自动添加div
 * update 2015/05/19 : 设置查词默认为小写
 * update 2015/05/09 : 按Ctrl可以使小蓝圈隐藏起来（暂时）
 * update 2015/01/03 : 样式全加了 !important 提高优先级
 * update 2014/12/24 : 添加设置选项（可当且仅当按住ctrl键显示翻译按钮）
 * update 2014/12/20 : 修正语法错误。。。
 * update 2014/12/19 : 搜词BUG修复，修正点击定位~
 * update 2014/12/10 : 严格模式'use strict'，提高性能
 * update 2014/12/04  : 贴吧图册预览修正
 * update 2014/11/16 : 更换mouseClick的触发条件为mouseup
 * update 2014/11/14 : 添加输入框查词，修正定位不正确。
 * ------------------------------------------------ */

(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
module.exports = { "default": require("core-js/library/fn/array/from"), __esModule: true };
},{"core-js/library/fn/array/from":5}],2:[function(require,module,exports){
module.exports = { "default": require("core-js/library/fn/promise"), __esModule: true };
},{"core-js/library/fn/promise":6}],3:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var _promise = require("../core-js/promise");

var _promise2 = _interopRequireDefault(_promise);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function (fn) {
  return function () {
    var gen = fn.apply(this, arguments);
    return new _promise2.default(function (resolve, reject) {
      function step(key, arg) {
        try {
          var info = gen[key](arg);
          var value = info.value;
        } catch (error) {
          reject(error);
          return;
        }

        if (info.done) {
          resolve(value);
        } else {
          return _promise2.default.resolve(value).then(function (value) {
            step("next", value);
          }, function (err) {
            step("throw", err);
          });
        }
      }

      return step("next");
    });
  };
};
},{"../core-js/promise":2}],4:[function(require,module,exports){
module.exports = require("regenerator-runtime");

},{"regenerator-runtime":72}],5:[function(require,module,exports){
require('../../modules/es6.string.iterator');
require('../../modules/es6.array.from');
module.exports = require('../../modules/_core').Array.from;
},{"../../modules/_core":14,"../../modules/es6.array.from":66,"../../modules/es6.string.iterator":70}],6:[function(require,module,exports){
require('../modules/es6.object.to-string');
require('../modules/es6.string.iterator');
require('../modules/web.dom.iterable');
require('../modules/es6.promise');
module.exports = require('../modules/_core').Promise;
},{"../modules/_core":14,"../modules/es6.object.to-string":68,"../modules/es6.promise":69,"../modules/es6.string.iterator":70,"../modules/web.dom.iterable":71}],7:[function(require,module,exports){
module.exports = function(it){
  if(typeof it != 'function')throw TypeError(it + ' is not a function!');
  return it;
};
},{}],8:[function(require,module,exports){
module.exports = function(){ /* empty */ };
},{}],9:[function(require,module,exports){
module.exports = function(it, Constructor, name, forbiddenField){
  if(!(it instanceof Constructor) || (forbiddenField !== undefined && forbiddenField in it)){
    throw TypeError(name + ': incorrect invocation!');
  } return it;
};
},{}],10:[function(require,module,exports){
var isObject = require('./_is-object');
module.exports = function(it){
  if(!isObject(it))throw TypeError(it + ' is not an object!');
  return it;
};
},{"./_is-object":32}],11:[function(require,module,exports){
// false -> Array#indexOf
// true  -> Array#includes
var toIObject = require('./_to-iobject')
  , toLength  = require('./_to-length')
  , toIndex   = require('./_to-index');
module.exports = function(IS_INCLUDES){
  return function($this, el, fromIndex){
    var O      = toIObject($this)
      , length = toLength(O.length)
      , index  = toIndex(fromIndex, length)
      , value;
    // Array#includes uses SameValueZero equality algorithm
    if(IS_INCLUDES && el != el)while(length > index){
      value = O[index++];
      if(value != value)return true;
    // Array#toIndex ignores holes, Array#includes - not
    } else for(;length > index; index++)if(IS_INCLUDES || index in O){
      if(O[index] === el)return IS_INCLUDES || index || 0;
    } return !IS_INCLUDES && -1;
  };
};
},{"./_to-index":57,"./_to-iobject":59,"./_to-length":60}],12:[function(require,module,exports){
// getting tag from 19.1.3.6 Object.prototype.toString()
var cof = require('./_cof')
  , TAG = require('./_wks')('toStringTag')
  // ES3 wrong here
  , ARG = cof(function(){ return arguments; }()) == 'Arguments';

// fallback for IE11 Script Access Denied error
var tryGet = function(it, key){
  try {
    return it[key];
  } catch(e){ /* empty */ }
};

module.exports = function(it){
  var O, T, B;
  return it === undefined ? 'Undefined' : it === null ? 'Null'
    // @@toStringTag case
    : typeof (T = tryGet(O = Object(it), TAG)) == 'string' ? T
    // builtinTag case
    : ARG ? cof(O)
    // ES3 arguments fallback
    : (B = cof(O)) == 'Object' && typeof O.callee == 'function' ? 'Arguments' : B;
};
},{"./_cof":13,"./_wks":64}],13:[function(require,module,exports){
var toString = {}.toString;

module.exports = function(it){
  return toString.call(it).slice(8, -1);
};
},{}],14:[function(require,module,exports){
var core = module.exports = {version: '2.4.0'};
if(typeof __e == 'number')__e = core; // eslint-disable-line no-undef
},{}],15:[function(require,module,exports){
'use strict';
var $defineProperty = require('./_object-dp')
  , createDesc      = require('./_property-desc');

module.exports = function(object, index, value){
  if(index in object)$defineProperty.f(object, index, createDesc(0, value));
  else object[index] = value;
};
},{"./_object-dp":42,"./_property-desc":47}],16:[function(require,module,exports){
// optional / simple context binding
var aFunction = require('./_a-function');
module.exports = function(fn, that, length){
  aFunction(fn);
  if(that === undefined)return fn;
  switch(length){
    case 1: return function(a){
      return fn.call(that, a);
    };
    case 2: return function(a, b){
      return fn.call(that, a, b);
    };
    case 3: return function(a, b, c){
      return fn.call(that, a, b, c);
    };
  }
  return function(/* ...args */){
    return fn.apply(that, arguments);
  };
};
},{"./_a-function":7}],17:[function(require,module,exports){
// 7.2.1 RequireObjectCoercible(argument)
module.exports = function(it){
  if(it == undefined)throw TypeError("Can't call method on  " + it);
  return it;
};
},{}],18:[function(require,module,exports){
// Thank's IE8 for his funny defineProperty
module.exports = !require('./_fails')(function(){
  return Object.defineProperty({}, 'a', {get: function(){ return 7; }}).a != 7;
});
},{"./_fails":22}],19:[function(require,module,exports){
var isObject = require('./_is-object')
  , document = require('./_global').document
  // in old IE typeof document.createElement is 'object'
  , is = isObject(document) && isObject(document.createElement);
module.exports = function(it){
  return is ? document.createElement(it) : {};
};
},{"./_global":24,"./_is-object":32}],20:[function(require,module,exports){
// IE 8- don't enum bug keys
module.exports = (
  'constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf'
).split(',');
},{}],21:[function(require,module,exports){
var global    = require('./_global')
  , core      = require('./_core')
  , ctx       = require('./_ctx')
  , hide      = require('./_hide')
  , PROTOTYPE = 'prototype';

var $export = function(type, name, source){
  var IS_FORCED = type & $export.F
    , IS_GLOBAL = type & $export.G
    , IS_STATIC = type & $export.S
    , IS_PROTO  = type & $export.P
    , IS_BIND   = type & $export.B
    , IS_WRAP   = type & $export.W
    , exports   = IS_GLOBAL ? core : core[name] || (core[name] = {})
    , expProto  = exports[PROTOTYPE]
    , target    = IS_GLOBAL ? global : IS_STATIC ? global[name] : (global[name] || {})[PROTOTYPE]
    , key, own, out;
  if(IS_GLOBAL)source = name;
  for(key in source){
    // contains in native
    own = !IS_FORCED && target && target[key] !== undefined;
    if(own && key in exports)continue;
    // export native or passed
    out = own ? target[key] : source[key];
    // prevent global pollution for namespaces
    exports[key] = IS_GLOBAL && typeof target[key] != 'function' ? source[key]
    // bind timers to global for call from export context
    : IS_BIND && own ? ctx(out, global)
    // wrap global constructors for prevent change them in library
    : IS_WRAP && target[key] == out ? (function(C){
      var F = function(a, b, c){
        if(this instanceof C){
          switch(arguments.length){
            case 0: return new C;
            case 1: return new C(a);
            case 2: return new C(a, b);
          } return new C(a, b, c);
        } return C.apply(this, arguments);
      };
      F[PROTOTYPE] = C[PROTOTYPE];
      return F;
    // make static versions for prototype methods
    })(out) : IS_PROTO && typeof out == 'function' ? ctx(Function.call, out) : out;
    // export proto methods to core.%CONSTRUCTOR%.methods.%NAME%
    if(IS_PROTO){
      (exports.virtual || (exports.virtual = {}))[key] = out;
      // export proto methods to core.%CONSTRUCTOR%.prototype.%NAME%
      if(type & $export.R && expProto && !expProto[key])hide(expProto, key, out);
    }
  }
};
// type bitmap
$export.F = 1;   // forced
$export.G = 2;   // global
$export.S = 4;   // static
$export.P = 8;   // proto
$export.B = 16;  // bind
$export.W = 32;  // wrap
$export.U = 64;  // safe
$export.R = 128; // real proto method for `library` 
module.exports = $export;
},{"./_core":14,"./_ctx":16,"./_global":24,"./_hide":26}],22:[function(require,module,exports){
module.exports = function(exec){
  try {
    return !!exec();
  } catch(e){
    return true;
  }
};
},{}],23:[function(require,module,exports){
var ctx         = require('./_ctx')
  , call        = require('./_iter-call')
  , isArrayIter = require('./_is-array-iter')
  , anObject    = require('./_an-object')
  , toLength    = require('./_to-length')
  , getIterFn   = require('./core.get-iterator-method')
  , BREAK       = {}
  , RETURN      = {};
var exports = module.exports = function(iterable, entries, fn, that, ITERATOR){
  var iterFn = ITERATOR ? function(){ return iterable; } : getIterFn(iterable)
    , f      = ctx(fn, that, entries ? 2 : 1)
    , index  = 0
    , length, step, iterator, result;
  if(typeof iterFn != 'function')throw TypeError(iterable + ' is not iterable!');
  // fast case for arrays with default iterator
  if(isArrayIter(iterFn))for(length = toLength(iterable.length); length > index; index++){
    result = entries ? f(anObject(step = iterable[index])[0], step[1]) : f(iterable[index]);
    if(result === BREAK || result === RETURN)return result;
  } else for(iterator = iterFn.call(iterable); !(step = iterator.next()).done; ){
    result = call(iterator, f, step.value, entries);
    if(result === BREAK || result === RETURN)return result;
  }
};
exports.BREAK  = BREAK;
exports.RETURN = RETURN;
},{"./_an-object":10,"./_ctx":16,"./_is-array-iter":31,"./_iter-call":33,"./_to-length":60,"./core.get-iterator-method":65}],24:[function(require,module,exports){
// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
var global = module.exports = typeof window != 'undefined' && window.Math == Math
  ? window : typeof self != 'undefined' && self.Math == Math ? self : Function('return this')();
if(typeof __g == 'number')__g = global; // eslint-disable-line no-undef
},{}],25:[function(require,module,exports){
var hasOwnProperty = {}.hasOwnProperty;
module.exports = function(it, key){
  return hasOwnProperty.call(it, key);
};
},{}],26:[function(require,module,exports){
var dP         = require('./_object-dp')
  , createDesc = require('./_property-desc');
module.exports = require('./_descriptors') ? function(object, key, value){
  return dP.f(object, key, createDesc(1, value));
} : function(object, key, value){
  object[key] = value;
  return object;
};
},{"./_descriptors":18,"./_object-dp":42,"./_property-desc":47}],27:[function(require,module,exports){
module.exports = require('./_global').document && document.documentElement;
},{"./_global":24}],28:[function(require,module,exports){
module.exports = !require('./_descriptors') && !require('./_fails')(function(){
  return Object.defineProperty(require('./_dom-create')('div'), 'a', {get: function(){ return 7; }}).a != 7;
});
},{"./_descriptors":18,"./_dom-create":19,"./_fails":22}],29:[function(require,module,exports){
// fast apply, http://jsperf.lnkit.com/fast-apply/5
module.exports = function(fn, args, that){
  var un = that === undefined;
  switch(args.length){
    case 0: return un ? fn()
                      : fn.call(that);
    case 1: return un ? fn(args[0])
                      : fn.call(that, args[0]);
    case 2: return un ? fn(args[0], args[1])
                      : fn.call(that, args[0], args[1]);
    case 3: return un ? fn(args[0], args[1], args[2])
                      : fn.call(that, args[0], args[1], args[2]);
    case 4: return un ? fn(args[0], args[1], args[2], args[3])
                      : fn.call(that, args[0], args[1], args[2], args[3]);
  } return              fn.apply(that, args);
};
},{}],30:[function(require,module,exports){
// fallback for non-array-like ES3 and non-enumerable old V8 strings
var cof = require('./_cof');
module.exports = Object('z').propertyIsEnumerable(0) ? Object : function(it){
  return cof(it) == 'String' ? it.split('') : Object(it);
};
},{"./_cof":13}],31:[function(require,module,exports){
// check on default Array iterator
var Iterators  = require('./_iterators')
  , ITERATOR   = require('./_wks')('iterator')
  , ArrayProto = Array.prototype;

module.exports = function(it){
  return it !== undefined && (Iterators.Array === it || ArrayProto[ITERATOR] === it);
};
},{"./_iterators":38,"./_wks":64}],32:[function(require,module,exports){
module.exports = function(it){
  return typeof it === 'object' ? it !== null : typeof it === 'function';
};
},{}],33:[function(require,module,exports){
// call something on iterator step with safe closing on error
var anObject = require('./_an-object');
module.exports = function(iterator, fn, value, entries){
  try {
    return entries ? fn(anObject(value)[0], value[1]) : fn(value);
  // 7.4.6 IteratorClose(iterator, completion)
  } catch(e){
    var ret = iterator['return'];
    if(ret !== undefined)anObject(ret.call(iterator));
    throw e;
  }
};
},{"./_an-object":10}],34:[function(require,module,exports){
'use strict';
var create         = require('./_object-create')
  , descriptor     = require('./_property-desc')
  , setToStringTag = require('./_set-to-string-tag')
  , IteratorPrototype = {};

// 25.1.2.1.1 %IteratorPrototype%[@@iterator]()
require('./_hide')(IteratorPrototype, require('./_wks')('iterator'), function(){ return this; });

module.exports = function(Constructor, NAME, next){
  Constructor.prototype = create(IteratorPrototype, {next: descriptor(1, next)});
  setToStringTag(Constructor, NAME + ' Iterator');
};
},{"./_hide":26,"./_object-create":41,"./_property-desc":47,"./_set-to-string-tag":51,"./_wks":64}],35:[function(require,module,exports){
'use strict';
var LIBRARY        = require('./_library')
  , $export        = require('./_export')
  , redefine       = require('./_redefine')
  , hide           = require('./_hide')
  , has            = require('./_has')
  , Iterators      = require('./_iterators')
  , $iterCreate    = require('./_iter-create')
  , setToStringTag = require('./_set-to-string-tag')
  , getPrototypeOf = require('./_object-gpo')
  , ITERATOR       = require('./_wks')('iterator')
  , BUGGY          = !([].keys && 'next' in [].keys()) // Safari has buggy iterators w/o `next`
  , FF_ITERATOR    = '@@iterator'
  , KEYS           = 'keys'
  , VALUES         = 'values';

var returnThis = function(){ return this; };

module.exports = function(Base, NAME, Constructor, next, DEFAULT, IS_SET, FORCED){
  $iterCreate(Constructor, NAME, next);
  var getMethod = function(kind){
    if(!BUGGY && kind in proto)return proto[kind];
    switch(kind){
      case KEYS: return function keys(){ return new Constructor(this, kind); };
      case VALUES: return function values(){ return new Constructor(this, kind); };
    } return function entries(){ return new Constructor(this, kind); };
  };
  var TAG        = NAME + ' Iterator'
    , DEF_VALUES = DEFAULT == VALUES
    , VALUES_BUG = false
    , proto      = Base.prototype
    , $native    = proto[ITERATOR] || proto[FF_ITERATOR] || DEFAULT && proto[DEFAULT]
    , $default   = $native || getMethod(DEFAULT)
    , $entries   = DEFAULT ? !DEF_VALUES ? $default : getMethod('entries') : undefined
    , $anyNative = NAME == 'Array' ? proto.entries || $native : $native
    , methods, key, IteratorPrototype;
  // Fix native
  if($anyNative){
    IteratorPrototype = getPrototypeOf($anyNative.call(new Base));
    if(IteratorPrototype !== Object.prototype){
      // Set @@toStringTag to native iterators
      setToStringTag(IteratorPrototype, TAG, true);
      // fix for some old engines
      if(!LIBRARY && !has(IteratorPrototype, ITERATOR))hide(IteratorPrototype, ITERATOR, returnThis);
    }
  }
  // fix Array#{values, @@iterator}.name in V8 / FF
  if(DEF_VALUES && $native && $native.name !== VALUES){
    VALUES_BUG = true;
    $default = function values(){ return $native.call(this); };
  }
  // Define iterator
  if((!LIBRARY || FORCED) && (BUGGY || VALUES_BUG || !proto[ITERATOR])){
    hide(proto, ITERATOR, $default);
  }
  // Plug for library
  Iterators[NAME] = $default;
  Iterators[TAG]  = returnThis;
  if(DEFAULT){
    methods = {
      values:  DEF_VALUES ? $default : getMethod(VALUES),
      keys:    IS_SET     ? $default : getMethod(KEYS),
      entries: $entries
    };
    if(FORCED)for(key in methods){
      if(!(key in proto))redefine(proto, key, methods[key]);
    } else $export($export.P + $export.F * (BUGGY || VALUES_BUG), NAME, methods);
  }
  return methods;
};
},{"./_export":21,"./_has":25,"./_hide":26,"./_iter-create":34,"./_iterators":38,"./_library":39,"./_object-gpo":44,"./_redefine":49,"./_set-to-string-tag":51,"./_wks":64}],36:[function(require,module,exports){
var ITERATOR     = require('./_wks')('iterator')
  , SAFE_CLOSING = false;

try {
  var riter = [7][ITERATOR]();
  riter['return'] = function(){ SAFE_CLOSING = true; };
  Array.from(riter, function(){ throw 2; });
} catch(e){ /* empty */ }

module.exports = function(exec, skipClosing){
  if(!skipClosing && !SAFE_CLOSING)return false;
  var safe = false;
  try {
    var arr  = [7]
      , iter = arr[ITERATOR]();
    iter.next = function(){ return {done: safe = true}; };
    arr[ITERATOR] = function(){ return iter; };
    exec(arr);
  } catch(e){ /* empty */ }
  return safe;
};
},{"./_wks":64}],37:[function(require,module,exports){
module.exports = function(done, value){
  return {value: value, done: !!done};
};
},{}],38:[function(require,module,exports){
module.exports = {};
},{}],39:[function(require,module,exports){
module.exports = true;
},{}],40:[function(require,module,exports){
var global    = require('./_global')
  , macrotask = require('./_task').set
  , Observer  = global.MutationObserver || global.WebKitMutationObserver
  , process   = global.process
  , Promise   = global.Promise
  , isNode    = require('./_cof')(process) == 'process';

module.exports = function(){
  var head, last, notify;

  var flush = function(){
    var parent, fn;
    if(isNode && (parent = process.domain))parent.exit();
    while(head){
      fn   = head.fn;
      head = head.next;
      try {
        fn();
      } catch(e){
        if(head)notify();
        else last = undefined;
        throw e;
      }
    } last = undefined;
    if(parent)parent.enter();
  };

  // Node.js
  if(isNode){
    notify = function(){
      process.nextTick(flush);
    };
  // browsers with MutationObserver
  } else if(Observer){
    var toggle = true
      , node   = document.createTextNode('');
    new Observer(flush).observe(node, {characterData: true}); // eslint-disable-line no-new
    notify = function(){
      node.data = toggle = !toggle;
    };
  // environments with maybe non-completely correct, but existent Promise
  } else if(Promise && Promise.resolve){
    var promise = Promise.resolve();
    notify = function(){
      promise.then(flush);
    };
  // for other environments - macrotask based on:
  // - setImmediate
  // - MessageChannel
  // - window.postMessag
  // - onreadystatechange
  // - setTimeout
  } else {
    notify = function(){
      // strange IE + webpack dev server bug - use .call(global)
      macrotask.call(global, flush);
    };
  }

  return function(fn){
    var task = {fn: fn, next: undefined};
    if(last)last.next = task;
    if(!head){
      head = task;
      notify();
    } last = task;
  };
};
},{"./_cof":13,"./_global":24,"./_task":56}],41:[function(require,module,exports){
// 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
var anObject    = require('./_an-object')
  , dPs         = require('./_object-dps')
  , enumBugKeys = require('./_enum-bug-keys')
  , IE_PROTO    = require('./_shared-key')('IE_PROTO')
  , Empty       = function(){ /* empty */ }
  , PROTOTYPE   = 'prototype';

// Create object with fake `null` prototype: use iframe Object with cleared prototype
var createDict = function(){
  // Thrash, waste and sodomy: IE GC bug
  var iframe = require('./_dom-create')('iframe')
    , i      = enumBugKeys.length
    , lt     = '<'
    , gt     = '>'
    , iframeDocument;
  iframe.style.display = 'none';
  require('./_html').appendChild(iframe);
  iframe.src = 'javascript:'; // eslint-disable-line no-script-url
  // createDict = iframe.contentWindow.Object;
  // html.removeChild(iframe);
  iframeDocument = iframe.contentWindow.document;
  iframeDocument.open();
  iframeDocument.write(lt + 'script' + gt + 'document.F=Object' + lt + '/script' + gt);
  iframeDocument.close();
  createDict = iframeDocument.F;
  while(i--)delete createDict[PROTOTYPE][enumBugKeys[i]];
  return createDict();
};

module.exports = Object.create || function create(O, Properties){
  var result;
  if(O !== null){
    Empty[PROTOTYPE] = anObject(O);
    result = new Empty;
    Empty[PROTOTYPE] = null;
    // add "__proto__" for Object.getPrototypeOf polyfill
    result[IE_PROTO] = O;
  } else result = createDict();
  return Properties === undefined ? result : dPs(result, Properties);
};

},{"./_an-object":10,"./_dom-create":19,"./_enum-bug-keys":20,"./_html":27,"./_object-dps":43,"./_shared-key":52}],42:[function(require,module,exports){
var anObject       = require('./_an-object')
  , IE8_DOM_DEFINE = require('./_ie8-dom-define')
  , toPrimitive    = require('./_to-primitive')
  , dP             = Object.defineProperty;

exports.f = require('./_descriptors') ? Object.defineProperty : function defineProperty(O, P, Attributes){
  anObject(O);
  P = toPrimitive(P, true);
  anObject(Attributes);
  if(IE8_DOM_DEFINE)try {
    return dP(O, P, Attributes);
  } catch(e){ /* empty */ }
  if('get' in Attributes || 'set' in Attributes)throw TypeError('Accessors not supported!');
  if('value' in Attributes)O[P] = Attributes.value;
  return O;
};
},{"./_an-object":10,"./_descriptors":18,"./_ie8-dom-define":28,"./_to-primitive":62}],43:[function(require,module,exports){
var dP       = require('./_object-dp')
  , anObject = require('./_an-object')
  , getKeys  = require('./_object-keys');

module.exports = require('./_descriptors') ? Object.defineProperties : function defineProperties(O, Properties){
  anObject(O);
  var keys   = getKeys(Properties)
    , length = keys.length
    , i = 0
    , P;
  while(length > i)dP.f(O, P = keys[i++], Properties[P]);
  return O;
};
},{"./_an-object":10,"./_descriptors":18,"./_object-dp":42,"./_object-keys":46}],44:[function(require,module,exports){
// 19.1.2.9 / 15.2.3.2 Object.getPrototypeOf(O)
var has         = require('./_has')
  , toObject    = require('./_to-object')
  , IE_PROTO    = require('./_shared-key')('IE_PROTO')
  , ObjectProto = Object.prototype;

module.exports = Object.getPrototypeOf || function(O){
  O = toObject(O);
  if(has(O, IE_PROTO))return O[IE_PROTO];
  if(typeof O.constructor == 'function' && O instanceof O.constructor){
    return O.constructor.prototype;
  } return O instanceof Object ? ObjectProto : null;
};
},{"./_has":25,"./_shared-key":52,"./_to-object":61}],45:[function(require,module,exports){
var has          = require('./_has')
  , toIObject    = require('./_to-iobject')
  , arrayIndexOf = require('./_array-includes')(false)
  , IE_PROTO     = require('./_shared-key')('IE_PROTO');

module.exports = function(object, names){
  var O      = toIObject(object)
    , i      = 0
    , result = []
    , key;
  for(key in O)if(key != IE_PROTO)has(O, key) && result.push(key);
  // Don't enum bug & hidden keys
  while(names.length > i)if(has(O, key = names[i++])){
    ~arrayIndexOf(result, key) || result.push(key);
  }
  return result;
};
},{"./_array-includes":11,"./_has":25,"./_shared-key":52,"./_to-iobject":59}],46:[function(require,module,exports){
// 19.1.2.14 / 15.2.3.14 Object.keys(O)
var $keys       = require('./_object-keys-internal')
  , enumBugKeys = require('./_enum-bug-keys');

module.exports = Object.keys || function keys(O){
  return $keys(O, enumBugKeys);
};
},{"./_enum-bug-keys":20,"./_object-keys-internal":45}],47:[function(require,module,exports){
module.exports = function(bitmap, value){
  return {
    enumerable  : !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable    : !(bitmap & 4),
    value       : value
  };
};
},{}],48:[function(require,module,exports){
var hide = require('./_hide');
module.exports = function(target, src, safe){
  for(var key in src){
    if(safe && target[key])target[key] = src[key];
    else hide(target, key, src[key]);
  } return target;
};
},{"./_hide":26}],49:[function(require,module,exports){
module.exports = require('./_hide');
},{"./_hide":26}],50:[function(require,module,exports){
'use strict';
var global      = require('./_global')
  , core        = require('./_core')
  , dP          = require('./_object-dp')
  , DESCRIPTORS = require('./_descriptors')
  , SPECIES     = require('./_wks')('species');

module.exports = function(KEY){
  var C = typeof core[KEY] == 'function' ? core[KEY] : global[KEY];
  if(DESCRIPTORS && C && !C[SPECIES])dP.f(C, SPECIES, {
    configurable: true,
    get: function(){ return this; }
  });
};
},{"./_core":14,"./_descriptors":18,"./_global":24,"./_object-dp":42,"./_wks":64}],51:[function(require,module,exports){
var def = require('./_object-dp').f
  , has = require('./_has')
  , TAG = require('./_wks')('toStringTag');

module.exports = function(it, tag, stat){
  if(it && !has(it = stat ? it : it.prototype, TAG))def(it, TAG, {configurable: true, value: tag});
};
},{"./_has":25,"./_object-dp":42,"./_wks":64}],52:[function(require,module,exports){
var shared = require('./_shared')('keys')
  , uid    = require('./_uid');
module.exports = function(key){
  return shared[key] || (shared[key] = uid(key));
};
},{"./_shared":53,"./_uid":63}],53:[function(require,module,exports){
var global = require('./_global')
  , SHARED = '__core-js_shared__'
  , store  = global[SHARED] || (global[SHARED] = {});
module.exports = function(key){
  return store[key] || (store[key] = {});
};
},{"./_global":24}],54:[function(require,module,exports){
// 7.3.20 SpeciesConstructor(O, defaultConstructor)
var anObject  = require('./_an-object')
  , aFunction = require('./_a-function')
  , SPECIES   = require('./_wks')('species');
module.exports = function(O, D){
  var C = anObject(O).constructor, S;
  return C === undefined || (S = anObject(C)[SPECIES]) == undefined ? D : aFunction(S);
};
},{"./_a-function":7,"./_an-object":10,"./_wks":64}],55:[function(require,module,exports){
var toInteger = require('./_to-integer')
  , defined   = require('./_defined');
// true  -> String#at
// false -> String#codePointAt
module.exports = function(TO_STRING){
  return function(that, pos){
    var s = String(defined(that))
      , i = toInteger(pos)
      , l = s.length
      , a, b;
    if(i < 0 || i >= l)return TO_STRING ? '' : undefined;
    a = s.charCodeAt(i);
    return a < 0xd800 || a > 0xdbff || i + 1 === l || (b = s.charCodeAt(i + 1)) < 0xdc00 || b > 0xdfff
      ? TO_STRING ? s.charAt(i) : a
      : TO_STRING ? s.slice(i, i + 2) : (a - 0xd800 << 10) + (b - 0xdc00) + 0x10000;
  };
};
},{"./_defined":17,"./_to-integer":58}],56:[function(require,module,exports){
var ctx                = require('./_ctx')
  , invoke             = require('./_invoke')
  , html               = require('./_html')
  , cel                = require('./_dom-create')
  , global             = require('./_global')
  , process            = global.process
  , setTask            = global.setImmediate
  , clearTask          = global.clearImmediate
  , MessageChannel     = global.MessageChannel
  , counter            = 0
  , queue              = {}
  , ONREADYSTATECHANGE = 'onreadystatechange'
  , defer, channel, port;
var run = function(){
  var id = +this;
  if(queue.hasOwnProperty(id)){
    var fn = queue[id];
    delete queue[id];
    fn();
  }
};
var listener = function(event){
  run.call(event.data);
};
// Node.js 0.9+ & IE10+ has setImmediate, otherwise:
if(!setTask || !clearTask){
  setTask = function setImmediate(fn){
    var args = [], i = 1;
    while(arguments.length > i)args.push(arguments[i++]);
    queue[++counter] = function(){
      invoke(typeof fn == 'function' ? fn : Function(fn), args);
    };
    defer(counter);
    return counter;
  };
  clearTask = function clearImmediate(id){
    delete queue[id];
  };
  // Node.js 0.8-
  if(require('./_cof')(process) == 'process'){
    defer = function(id){
      process.nextTick(ctx(run, id, 1));
    };
  // Browsers with MessageChannel, includes WebWorkers
  } else if(MessageChannel){
    channel = new MessageChannel;
    port    = channel.port2;
    channel.port1.onmessage = listener;
    defer = ctx(port.postMessage, port, 1);
  // Browsers with postMessage, skip WebWorkers
  // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
  } else if(global.addEventListener && typeof postMessage == 'function' && !global.importScripts){
    defer = function(id){
      global.postMessage(id + '', '*');
    };
    global.addEventListener('message', listener, false);
  // IE8-
  } else if(ONREADYSTATECHANGE in cel('script')){
    defer = function(id){
      html.appendChild(cel('script'))[ONREADYSTATECHANGE] = function(){
        html.removeChild(this);
        run.call(id);
      };
    };
  // Rest old browsers
  } else {
    defer = function(id){
      setTimeout(ctx(run, id, 1), 0);
    };
  }
}
module.exports = {
  set:   setTask,
  clear: clearTask
};
},{"./_cof":13,"./_ctx":16,"./_dom-create":19,"./_global":24,"./_html":27,"./_invoke":29}],57:[function(require,module,exports){
var toInteger = require('./_to-integer')
  , max       = Math.max
  , min       = Math.min;
module.exports = function(index, length){
  index = toInteger(index);
  return index < 0 ? max(index + length, 0) : min(index, length);
};
},{"./_to-integer":58}],58:[function(require,module,exports){
// 7.1.4 ToInteger
var ceil  = Math.ceil
  , floor = Math.floor;
module.exports = function(it){
  return isNaN(it = +it) ? 0 : (it > 0 ? floor : ceil)(it);
};
},{}],59:[function(require,module,exports){
// to indexed object, toObject with fallback for non-array-like ES3 strings
var IObject = require('./_iobject')
  , defined = require('./_defined');
module.exports = function(it){
  return IObject(defined(it));
};
},{"./_defined":17,"./_iobject":30}],60:[function(require,module,exports){
// 7.1.15 ToLength
var toInteger = require('./_to-integer')
  , min       = Math.min;
module.exports = function(it){
  return it > 0 ? min(toInteger(it), 0x1fffffffffffff) : 0; // pow(2, 53) - 1 == 9007199254740991
};
},{"./_to-integer":58}],61:[function(require,module,exports){
// 7.1.13 ToObject(argument)
var defined = require('./_defined');
module.exports = function(it){
  return Object(defined(it));
};
},{"./_defined":17}],62:[function(require,module,exports){
// 7.1.1 ToPrimitive(input [, PreferredType])
var isObject = require('./_is-object');
// instead of the ES6 spec version, we didn't implement @@toPrimitive case
// and the second argument - flag - preferred type is a string
module.exports = function(it, S){
  if(!isObject(it))return it;
  var fn, val;
  if(S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it)))return val;
  if(typeof (fn = it.valueOf) == 'function' && !isObject(val = fn.call(it)))return val;
  if(!S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it)))return val;
  throw TypeError("Can't convert object to primitive value");
};
},{"./_is-object":32}],63:[function(require,module,exports){
var id = 0
  , px = Math.random();
module.exports = function(key){
  return 'Symbol('.concat(key === undefined ? '' : key, ')_', (++id + px).toString(36));
};
},{}],64:[function(require,module,exports){
var store      = require('./_shared')('wks')
  , uid        = require('./_uid')
  , Symbol     = require('./_global').Symbol
  , USE_SYMBOL = typeof Symbol == 'function';

var $exports = module.exports = function(name){
  return store[name] || (store[name] =
    USE_SYMBOL && Symbol[name] || (USE_SYMBOL ? Symbol : uid)('Symbol.' + name));
};

$exports.store = store;
},{"./_global":24,"./_shared":53,"./_uid":63}],65:[function(require,module,exports){
var classof   = require('./_classof')
  , ITERATOR  = require('./_wks')('iterator')
  , Iterators = require('./_iterators');
module.exports = require('./_core').getIteratorMethod = function(it){
  if(it != undefined)return it[ITERATOR]
    || it['@@iterator']
    || Iterators[classof(it)];
};
},{"./_classof":12,"./_core":14,"./_iterators":38,"./_wks":64}],66:[function(require,module,exports){
'use strict';
var ctx            = require('./_ctx')
  , $export        = require('./_export')
  , toObject       = require('./_to-object')
  , call           = require('./_iter-call')
  , isArrayIter    = require('./_is-array-iter')
  , toLength       = require('./_to-length')
  , createProperty = require('./_create-property')
  , getIterFn      = require('./core.get-iterator-method');

$export($export.S + $export.F * !require('./_iter-detect')(function(iter){ Array.from(iter); }), 'Array', {
  // 22.1.2.1 Array.from(arrayLike, mapfn = undefined, thisArg = undefined)
  from: function from(arrayLike/*, mapfn = undefined, thisArg = undefined*/){
    var O       = toObject(arrayLike)
      , C       = typeof this == 'function' ? this : Array
      , aLen    = arguments.length
      , mapfn   = aLen > 1 ? arguments[1] : undefined
      , mapping = mapfn !== undefined
      , index   = 0
      , iterFn  = getIterFn(O)
      , length, result, step, iterator;
    if(mapping)mapfn = ctx(mapfn, aLen > 2 ? arguments[2] : undefined, 2);
    // if object isn't iterable or it's array with default iterator - use simple case
    if(iterFn != undefined && !(C == Array && isArrayIter(iterFn))){
      for(iterator = iterFn.call(O), result = new C; !(step = iterator.next()).done; index++){
        createProperty(result, index, mapping ? call(iterator, mapfn, [step.value, index], true) : step.value);
      }
    } else {
      length = toLength(O.length);
      for(result = new C(length); length > index; index++){
        createProperty(result, index, mapping ? mapfn(O[index], index) : O[index]);
      }
    }
    result.length = index;
    return result;
  }
});

},{"./_create-property":15,"./_ctx":16,"./_export":21,"./_is-array-iter":31,"./_iter-call":33,"./_iter-detect":36,"./_to-length":60,"./_to-object":61,"./core.get-iterator-method":65}],67:[function(require,module,exports){
'use strict';
var addToUnscopables = require('./_add-to-unscopables')
  , step             = require('./_iter-step')
  , Iterators        = require('./_iterators')
  , toIObject        = require('./_to-iobject');

// 22.1.3.4 Array.prototype.entries()
// 22.1.3.13 Array.prototype.keys()
// 22.1.3.29 Array.prototype.values()
// 22.1.3.30 Array.prototype[@@iterator]()
module.exports = require('./_iter-define')(Array, 'Array', function(iterated, kind){
  this._t = toIObject(iterated); // target
  this._i = 0;                   // next index
  this._k = kind;                // kind
// 22.1.5.2.1 %ArrayIteratorPrototype%.next()
}, function(){
  var O     = this._t
    , kind  = this._k
    , index = this._i++;
  if(!O || index >= O.length){
    this._t = undefined;
    return step(1);
  }
  if(kind == 'keys'  )return step(0, index);
  if(kind == 'values')return step(0, O[index]);
  return step(0, [index, O[index]]);
}, 'values');

// argumentsList[@@iterator] is %ArrayProto_values% (9.4.4.6, 9.4.4.7)
Iterators.Arguments = Iterators.Array;

addToUnscopables('keys');
addToUnscopables('values');
addToUnscopables('entries');
},{"./_add-to-unscopables":8,"./_iter-define":35,"./_iter-step":37,"./_iterators":38,"./_to-iobject":59}],68:[function(require,module,exports){

},{}],69:[function(require,module,exports){
'use strict';
var LIBRARY            = require('./_library')
  , global             = require('./_global')
  , ctx                = require('./_ctx')
  , classof            = require('./_classof')
  , $export            = require('./_export')
  , isObject           = require('./_is-object')
  , aFunction          = require('./_a-function')
  , anInstance         = require('./_an-instance')
  , forOf              = require('./_for-of')
  , speciesConstructor = require('./_species-constructor')
  , task               = require('./_task').set
  , microtask          = require('./_microtask')()
  , PROMISE            = 'Promise'
  , TypeError          = global.TypeError
  , process            = global.process
  , $Promise           = global[PROMISE]
  , process            = global.process
  , isNode             = classof(process) == 'process'
  , empty              = function(){ /* empty */ }
  , Internal, GenericPromiseCapability, Wrapper;

var USE_NATIVE = !!function(){
  try {
    // correct subclassing with @@species support
    var promise     = $Promise.resolve(1)
      , FakePromise = (promise.constructor = {})[require('./_wks')('species')] = function(exec){ exec(empty, empty); };
    // unhandled rejections tracking support, NodeJS Promise without it fails @@species test
    return (isNode || typeof PromiseRejectionEvent == 'function') && promise.then(empty) instanceof FakePromise;
  } catch(e){ /* empty */ }
}();

// helpers
var sameConstructor = function(a, b){
  // with library wrapper special case
  return a === b || a === $Promise && b === Wrapper;
};
var isThenable = function(it){
  var then;
  return isObject(it) && typeof (then = it.then) == 'function' ? then : false;
};
var newPromiseCapability = function(C){
  return sameConstructor($Promise, C)
    ? new PromiseCapability(C)
    : new GenericPromiseCapability(C);
};
var PromiseCapability = GenericPromiseCapability = function(C){
  var resolve, reject;
  this.promise = new C(function($$resolve, $$reject){
    if(resolve !== undefined || reject !== undefined)throw TypeError('Bad Promise constructor');
    resolve = $$resolve;
    reject  = $$reject;
  });
  this.resolve = aFunction(resolve);
  this.reject  = aFunction(reject);
};
var perform = function(exec){
  try {
    exec();
  } catch(e){
    return {error: e};
  }
};
var notify = function(promise, isReject){
  if(promise._n)return;
  promise._n = true;
  var chain = promise._c;
  microtask(function(){
    var value = promise._v
      , ok    = promise._s == 1
      , i     = 0;
    var run = function(reaction){
      var handler = ok ? reaction.ok : reaction.fail
        , resolve = reaction.resolve
        , reject  = reaction.reject
        , domain  = reaction.domain
        , result, then;
      try {
        if(handler){
          if(!ok){
            if(promise._h == 2)onHandleUnhandled(promise);
            promise._h = 1;
          }
          if(handler === true)result = value;
          else {
            if(domain)domain.enter();
            result = handler(value);
            if(domain)domain.exit();
          }
          if(result === reaction.promise){
            reject(TypeError('Promise-chain cycle'));
          } else if(then = isThenable(result)){
            then.call(result, resolve, reject);
          } else resolve(result);
        } else reject(value);
      } catch(e){
        reject(e);
      }
    };
    while(chain.length > i)run(chain[i++]); // variable length - can't use forEach
    promise._c = [];
    promise._n = false;
    if(isReject && !promise._h)onUnhandled(promise);
  });
};
var onUnhandled = function(promise){
  task.call(global, function(){
    var value = promise._v
      , abrupt, handler, console;
    if(isUnhandled(promise)){
      abrupt = perform(function(){
        if(isNode){
          process.emit('unhandledRejection', value, promise);
        } else if(handler = global.onunhandledrejection){
          handler({promise: promise, reason: value});
        } else if((console = global.console) && console.error){
          console.error('Unhandled promise rejection', value);
        }
      });
      // Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
      promise._h = isNode || isUnhandled(promise) ? 2 : 1;
    } promise._a = undefined;
    if(abrupt)throw abrupt.error;
  });
};
var isUnhandled = function(promise){
  if(promise._h == 1)return false;
  var chain = promise._a || promise._c
    , i     = 0
    , reaction;
  while(chain.length > i){
    reaction = chain[i++];
    if(reaction.fail || !isUnhandled(reaction.promise))return false;
  } return true;
};
var onHandleUnhandled = function(promise){
  task.call(global, function(){
    var handler;
    if(isNode){
      process.emit('rejectionHandled', promise);
    } else if(handler = global.onrejectionhandled){
      handler({promise: promise, reason: promise._v});
    }
  });
};
var $reject = function(value){
  var promise = this;
  if(promise._d)return;
  promise._d = true;
  promise = promise._w || promise; // unwrap
  promise._v = value;
  promise._s = 2;
  if(!promise._a)promise._a = promise._c.slice();
  notify(promise, true);
};
var $resolve = function(value){
  var promise = this
    , then;
  if(promise._d)return;
  promise._d = true;
  promise = promise._w || promise; // unwrap
  try {
    if(promise === value)throw TypeError("Promise can't be resolved itself");
    if(then = isThenable(value)){
      microtask(function(){
        var wrapper = {_w: promise, _d: false}; // wrap
        try {
          then.call(value, ctx($resolve, wrapper, 1), ctx($reject, wrapper, 1));
        } catch(e){
          $reject.call(wrapper, e);
        }
      });
    } else {
      promise._v = value;
      promise._s = 1;
      notify(promise, false);
    }
  } catch(e){
    $reject.call({_w: promise, _d: false}, e); // wrap
  }
};

// constructor polyfill
if(!USE_NATIVE){
  // 25.4.3.1 Promise(executor)
  $Promise = function Promise(executor){
    anInstance(this, $Promise, PROMISE, '_h');
    aFunction(executor);
    Internal.call(this);
    try {
      executor(ctx($resolve, this, 1), ctx($reject, this, 1));
    } catch(err){
      $reject.call(this, err);
    }
  };
  Internal = function Promise(executor){
    this._c = [];             // <- awaiting reactions
    this._a = undefined;      // <- checked in isUnhandled reactions
    this._s = 0;              // <- state
    this._d = false;          // <- done
    this._v = undefined;      // <- value
    this._h = 0;              // <- rejection state, 0 - default, 1 - handled, 2 - unhandled
    this._n = false;          // <- notify
  };
  Internal.prototype = require('./_redefine-all')($Promise.prototype, {
    // 25.4.5.3 Promise.prototype.then(onFulfilled, onRejected)
    then: function then(onFulfilled, onRejected){
      var reaction    = newPromiseCapability(speciesConstructor(this, $Promise));
      reaction.ok     = typeof onFulfilled == 'function' ? onFulfilled : true;
      reaction.fail   = typeof onRejected == 'function' && onRejected;
      reaction.domain = isNode ? process.domain : undefined;
      this._c.push(reaction);
      if(this._a)this._a.push(reaction);
      if(this._s)notify(this, false);
      return reaction.promise;
    },
    // 25.4.5.1 Promise.prototype.catch(onRejected)
    'catch': function(onRejected){
      return this.then(undefined, onRejected);
    }
  });
  PromiseCapability = function(){
    var promise  = new Internal;
    this.promise = promise;
    this.resolve = ctx($resolve, promise, 1);
    this.reject  = ctx($reject, promise, 1);
  };
}

$export($export.G + $export.W + $export.F * !USE_NATIVE, {Promise: $Promise});
require('./_set-to-string-tag')($Promise, PROMISE);
require('./_set-species')(PROMISE);
Wrapper = require('./_core')[PROMISE];

// statics
$export($export.S + $export.F * !USE_NATIVE, PROMISE, {
  // 25.4.4.5 Promise.reject(r)
  reject: function reject(r){
    var capability = newPromiseCapability(this)
      , $$reject   = capability.reject;
    $$reject(r);
    return capability.promise;
  }
});
$export($export.S + $export.F * (LIBRARY || !USE_NATIVE), PROMISE, {
  // 25.4.4.6 Promise.resolve(x)
  resolve: function resolve(x){
    // instanceof instead of internal slot check because we should fix it without replacement native Promise core
    if(x instanceof $Promise && sameConstructor(x.constructor, this))return x;
    var capability = newPromiseCapability(this)
      , $$resolve  = capability.resolve;
    $$resolve(x);
    return capability.promise;
  }
});
$export($export.S + $export.F * !(USE_NATIVE && require('./_iter-detect')(function(iter){
  $Promise.all(iter)['catch'](empty);
})), PROMISE, {
  // 25.4.4.1 Promise.all(iterable)
  all: function all(iterable){
    var C          = this
      , capability = newPromiseCapability(C)
      , resolve    = capability.resolve
      , reject     = capability.reject;
    var abrupt = perform(function(){
      var values    = []
        , index     = 0
        , remaining = 1;
      forOf(iterable, false, function(promise){
        var $index        = index++
          , alreadyCalled = false;
        values.push(undefined);
        remaining++;
        C.resolve(promise).then(function(value){
          if(alreadyCalled)return;
          alreadyCalled  = true;
          values[$index] = value;
          --remaining || resolve(values);
        }, reject);
      });
      --remaining || resolve(values);
    });
    if(abrupt)reject(abrupt.error);
    return capability.promise;
  },
  // 25.4.4.4 Promise.race(iterable)
  race: function race(iterable){
    var C          = this
      , capability = newPromiseCapability(C)
      , reject     = capability.reject;
    var abrupt = perform(function(){
      forOf(iterable, false, function(promise){
        C.resolve(promise).then(capability.resolve, reject);
      });
    });
    if(abrupt)reject(abrupt.error);
    return capability.promise;
  }
});
},{"./_a-function":7,"./_an-instance":9,"./_classof":12,"./_core":14,"./_ctx":16,"./_export":21,"./_for-of":23,"./_global":24,"./_is-object":32,"./_iter-detect":36,"./_library":39,"./_microtask":40,"./_redefine-all":48,"./_set-species":50,"./_set-to-string-tag":51,"./_species-constructor":54,"./_task":56,"./_wks":64}],70:[function(require,module,exports){
'use strict';
var $at  = require('./_string-at')(true);

// 21.1.3.27 String.prototype[@@iterator]()
require('./_iter-define')(String, 'String', function(iterated){
  this._t = String(iterated); // target
  this._i = 0;                // next index
// 21.1.5.2.1 %StringIteratorPrototype%.next()
}, function(){
  var O     = this._t
    , index = this._i
    , point;
  if(index >= O.length)return {value: undefined, done: true};
  point = $at(O, index);
  this._i += point.length;
  return {value: point, done: false};
});
},{"./_iter-define":35,"./_string-at":55}],71:[function(require,module,exports){
require('./es6.array.iterator');
var global        = require('./_global')
  , hide          = require('./_hide')
  , Iterators     = require('./_iterators')
  , TO_STRING_TAG = require('./_wks')('toStringTag');

for(var collections = ['NodeList', 'DOMTokenList', 'MediaList', 'StyleSheetList', 'CSSRuleList'], i = 0; i < 5; i++){
  var NAME       = collections[i]
    , Collection = global[NAME]
    , proto      = Collection && Collection.prototype;
  if(proto && !proto[TO_STRING_TAG])hide(proto, TO_STRING_TAG, NAME);
  Iterators[NAME] = Iterators.Array;
}
},{"./_global":24,"./_hide":26,"./_iterators":38,"./_wks":64,"./es6.array.iterator":67}],72:[function(require,module,exports){
(function (global){
// This method of obtaining a reference to the global object needs to be
// kept identical to the way it is obtained in runtime.js
var g =
  typeof global === "object" ? global :
  typeof window === "object" ? window :
  typeof self === "object" ? self : this;

// Use `getOwnPropertyNames` because not all browsers support calling
// `hasOwnProperty` on the global `self` object in a worker. See #183.
var hadRuntime = g.regeneratorRuntime &&
  Object.getOwnPropertyNames(g).indexOf("regeneratorRuntime") >= 0;

// Save the old regeneratorRuntime in case it needs to be restored later.
var oldRuntime = hadRuntime && g.regeneratorRuntime;

// Force reevalutation of runtime.js.
g.regeneratorRuntime = undefined;

module.exports = require("./runtime");

if (hadRuntime) {
  // Restore the original runtime.
  g.regeneratorRuntime = oldRuntime;
} else {
  // Remove the global property added by runtime.js.
  try {
    delete g.regeneratorRuntime;
  } catch(e) {
    g.regeneratorRuntime = undefined;
  }
}

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{"./runtime":73}],73:[function(require,module,exports){
(function (global){
/**
 * Copyright (c) 2014, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * https://raw.github.com/facebook/regenerator/master/LICENSE file. An
 * additional grant of patent rights can be found in the PATENTS file in
 * the same directory.
 */

!(function(global) {
  "use strict";

  var Op = Object.prototype;
  var hasOwn = Op.hasOwnProperty;
  var undefined; // More compressible than void 0.
  var $Symbol = typeof Symbol === "function" ? Symbol : {};
  var iteratorSymbol = $Symbol.iterator || "@@iterator";
  var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
  var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";

  var inModule = typeof module === "object";
  var runtime = global.regeneratorRuntime;
  if (runtime) {
    if (inModule) {
      // If regeneratorRuntime is defined globally and we're in a module,
      // make the exports object identical to regeneratorRuntime.
      module.exports = runtime;
    }
    // Don't bother evaluating the rest of this file if the runtime was
    // already defined globally.
    return;
  }

  // Define the runtime globally (as expected by generated code) as either
  // module.exports (if we're in a module) or a new, empty object.
  runtime = global.regeneratorRuntime = inModule ? module.exports : {};

  function wrap(innerFn, outerFn, self, tryLocsList) {
    // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
    var generator = Object.create(protoGenerator.prototype);
    var context = new Context(tryLocsList || []);

    // The ._invoke method unifies the implementations of the .next,
    // .throw, and .return methods.
    generator._invoke = makeInvokeMethod(innerFn, self, context);

    return generator;
  }
  runtime.wrap = wrap;

  // Try/catch helper to minimize deoptimizations. Returns a completion
  // record like context.tryEntries[i].completion. This interface could
  // have been (and was previously) designed to take a closure to be
  // invoked without arguments, but in all the cases we care about we
  // already have an existing method we want to call, so there's no need
  // to create a new function object. We can even get away with assuming
  // the method takes exactly one argument, since that happens to be true
  // in every case, so we don't have to touch the arguments object. The
  // only additional allocation required is the completion record, which
  // has a stable shape and so hopefully should be cheap to allocate.
  function tryCatch(fn, obj, arg) {
    try {
      return { type: "normal", arg: fn.call(obj, arg) };
    } catch (err) {
      return { type: "throw", arg: err };
    }
  }

  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";

  // Returning this object from the innerFn has the same effect as
  // breaking out of the dispatch switch statement.
  var ContinueSentinel = {};

  // Dummy constructor functions that we use as the .constructor and
  // .constructor.prototype properties for functions that return Generator
  // objects. For full spec compliance, you may wish to configure your
  // minifier not to mangle the names of these two functions.
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}

  // This is a polyfill for %IteratorPrototype% for environments that
  // don't natively support it.
  var IteratorPrototype = {};
  IteratorPrototype[iteratorSymbol] = function () {
    return this;
  };

  var getProto = Object.getPrototypeOf;
  var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  if (NativeIteratorPrototype &&
      NativeIteratorPrototype !== Op &&
      hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
    // This environment has a native %IteratorPrototype%; use it instead
    // of the polyfill.
    IteratorPrototype = NativeIteratorPrototype;
  }

  var Gp = GeneratorFunctionPrototype.prototype =
    Generator.prototype = Object.create(IteratorPrototype);
  GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
  GeneratorFunctionPrototype.constructor = GeneratorFunction;
  GeneratorFunctionPrototype[toStringTagSymbol] =
    GeneratorFunction.displayName = "GeneratorFunction";

  // Helper for defining the .next, .throw, and .return methods of the
  // Iterator interface in terms of a single ._invoke method.
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function(method) {
      prototype[method] = function(arg) {
        return this._invoke(method, arg);
      };
    });
  }

  runtime.isGeneratorFunction = function(genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor
      ? ctor === GeneratorFunction ||
        // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        (ctor.displayName || ctor.name) === "GeneratorFunction"
      : false;
  };

  runtime.mark = function(genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;
      if (!(toStringTagSymbol in genFun)) {
        genFun[toStringTagSymbol] = "GeneratorFunction";
      }
    }
    genFun.prototype = Object.create(Gp);
    return genFun;
  };

  // Within the body of any async function, `await x` is transformed to
  // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
  // `hasOwn.call(value, "__await")` to determine if the yielded value is
  // meant to be awaited.
  runtime.awrap = function(arg) {
    return { __await: arg };
  };

  function AsyncIterator(generator) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if (record.type === "throw") {
        reject(record.arg);
      } else {
        var result = record.arg;
        var value = result.value;
        if (value &&
            typeof value === "object" &&
            hasOwn.call(value, "__await")) {
          return Promise.resolve(value.__await).then(function(value) {
            invoke("next", value, resolve, reject);
          }, function(err) {
            invoke("throw", err, resolve, reject);
          });
        }

        return Promise.resolve(value).then(function(unwrapped) {
          // When a yielded Promise is resolved, its final value becomes
          // the .value of the Promise<{value,done}> result for the
          // current iteration. If the Promise is rejected, however, the
          // result for this iteration will be rejected with the same
          // reason. Note that rejections of yielded Promises are not
          // thrown back into the generator function, as is the case
          // when an awaited Promise is rejected. This difference in
          // behavior between yield and await is important, because it
          // allows the consumer to decide what to do with the yielded
          // rejection (swallow it and continue, manually .throw it back
          // into the generator, abandon iteration, whatever). With
          // await, by contrast, there is no opportunity to examine the
          // rejection reason outside the generator function, so the
          // only option is to throw it from the await expression, and
          // let the generator function handle the exception.
          result.value = unwrapped;
          resolve(result);
        }, reject);
      }
    }

    if (typeof global.process === "object" && global.process.domain) {
      invoke = global.process.domain.bind(invoke);
    }

    var previousPromise;

    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return new Promise(function(resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }

      return previousPromise =
        // If enqueue has been called before, then we want to wait until
        // all previous Promises have been resolved before calling invoke,
        // so that results are always delivered in the correct order. If
        // enqueue has not been called before, then it is important to
        // call invoke immediately, without waiting on a callback to fire,
        // so that the async generator function has the opportunity to do
        // any necessary setup in a predictable way. This predictability
        // is why the Promise constructor synchronously invokes its
        // executor callback, and why async functions synchronously
        // execute code before the first await. Since we implement simple
        // async functions in terms of async generators, it is especially
        // important to get this right, even though it requires care.
        previousPromise ? previousPromise.then(
          callInvokeWithMethodAndArg,
          // Avoid propagating failures to Promises returned by later
          // invocations of the iterator.
          callInvokeWithMethodAndArg
        ) : callInvokeWithMethodAndArg();
    }

    // Define the unified helper method that is used to implement .next,
    // .throw, and .return (see defineIteratorMethods).
    this._invoke = enqueue;
  }

  defineIteratorMethods(AsyncIterator.prototype);
  AsyncIterator.prototype[asyncIteratorSymbol] = function () {
    return this;
  };
  runtime.AsyncIterator = AsyncIterator;

  // Note that simple async functions are implemented on top of
  // AsyncIterator objects; they just return a Promise for the value of
  // the final result produced by the iterator.
  runtime.async = function(innerFn, outerFn, self, tryLocsList) {
    var iter = new AsyncIterator(
      wrap(innerFn, outerFn, self, tryLocsList)
    );

    return runtime.isGeneratorFunction(outerFn)
      ? iter // If outerFn is a generator, return the full iterator.
      : iter.next().then(function(result) {
          return result.done ? result.value : iter.next();
        });
  };

  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;

    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }

      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }

        // Be forgiving, per 25.3.3.3.3 of the spec:
        // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
        return doneResult();
      }

      context.method = method;
      context.arg = arg;

      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel) continue;
            return delegateResult;
          }
        }

        if (context.method === "next") {
          // Setting context._sent for legacy support of Babel's
          // function.sent implementation.
          context.sent = context._sent = context.arg;

        } else if (context.method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw context.arg;
          }

          context.dispatchException(context.arg);

        } else if (context.method === "return") {
          context.abrupt("return", context.arg);
        }

        state = GenStateExecuting;

        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          // If an exception is thrown from innerFn, we leave state ===
          // GenStateExecuting and loop back for another invocation.
          state = context.done
            ? GenStateCompleted
            : GenStateSuspendedYield;

          if (record.arg === ContinueSentinel) {
            continue;
          }

          return {
            value: record.arg,
            done: context.done
          };

        } else if (record.type === "throw") {
          state = GenStateCompleted;
          // Dispatch the exception by looping back around to the
          // context.dispatchException(context.arg) call above.
          context.method = "throw";
          context.arg = record.arg;
        }
      }
    };
  }

  // Call delegate.iterator[context.method](context.arg) and handle the
  // result, either by returning a { value, done } result from the
  // delegate iterator, or by modifying context.method and context.arg,
  // setting context.delegate to null, and returning the ContinueSentinel.
  function maybeInvokeDelegate(delegate, context) {
    var method = delegate.iterator[context.method];
    if (method === undefined) {
      // A .throw or .return when the delegate iterator has no .throw
      // method always terminates the yield* loop.
      context.delegate = null;

      if (context.method === "throw") {
        if (delegate.iterator.return) {
          // If the delegate iterator has a return method, give it a
          // chance to clean up.
          context.method = "return";
          context.arg = undefined;
          maybeInvokeDelegate(delegate, context);

          if (context.method === "throw") {
            // If maybeInvokeDelegate(context) changed context.method from
            // "return" to "throw", let that override the TypeError below.
            return ContinueSentinel;
          }
        }

        context.method = "throw";
        context.arg = new TypeError(
          "The iterator does not provide a 'throw' method");
      }

      return ContinueSentinel;
    }

    var record = tryCatch(method, delegate.iterator, context.arg);

    if (record.type === "throw") {
      context.method = "throw";
      context.arg = record.arg;
      context.delegate = null;
      return ContinueSentinel;
    }

    var info = record.arg;

    if (! info) {
      context.method = "throw";
      context.arg = new TypeError("iterator result is not an object");
      context.delegate = null;
      return ContinueSentinel;
    }

    if (info.done) {
      // Assign the result of the finished delegate to the temporary
      // variable specified by delegate.resultName (see delegateYield).
      context[delegate.resultName] = info.value;

      // Resume execution at the desired location (see delegateYield).
      context.next = delegate.nextLoc;

      // If context.method was "throw" but the delegate handled the
      // exception, let the outer generator proceed normally. If
      // context.method was "next", forget context.arg since it has been
      // "consumed" by the delegate iterator. If context.method was
      // "return", allow the original .return call to continue in the
      // outer generator.
      if (context.method !== "return") {
        context.method = "next";
        context.arg = undefined;
      }

    } else {
      // Re-yield the result returned by the delegate method.
      return info;
    }

    // The delegate iterator is finished, so forget it and continue with
    // the outer generator.
    context.delegate = null;
    return ContinueSentinel;
  }

  // Define Generator.prototype.{next,throw,return} in terms of the
  // unified ._invoke helper method.
  defineIteratorMethods(Gp);

  Gp[toStringTagSymbol] = "Generator";

  // A Generator should always return itself as the iterator object when the
  // @@iterator function is called on it. Some browsers' implementations of the
  // iterator prototype chain incorrectly implement this, causing the Generator
  // object to not be returned from this call. This ensures that doesn't happen.
  // See https://github.com/facebook/regenerator/issues/274 for more details.
  Gp[iteratorSymbol] = function() {
    return this;
  };

  Gp.toString = function() {
    return "[object Generator]";
  };

  function pushTryEntry(locs) {
    var entry = { tryLoc: locs[0] };

    if (1 in locs) {
      entry.catchLoc = locs[1];
    }

    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }

    this.tryEntries.push(entry);
  }

  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }

  function Context(tryLocsList) {
    // The root entry object (effectively a try statement without a catch
    // or a finally block) gives us a place to store values thrown from
    // locations where there is no enclosing try statement.
    this.tryEntries = [{ tryLoc: "root" }];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }

  runtime.keys = function(object) {
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();

    // Rather than returning an object with a next method, we keep
    // things simple and return the next function itself.
    return function next() {
      while (keys.length) {
        var key = keys.pop();
        if (key in object) {
          next.value = key;
          next.done = false;
          return next;
        }
      }

      // To avoid creating an additional object, we just hang the .value
      // and .done properties off the next function object itself. This
      // also ensures that the minifier will not anonymize the function.
      next.done = true;
      return next;
    };
  };

  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }

      if (typeof iterable.next === "function") {
        return iterable;
      }

      if (!isNaN(iterable.length)) {
        var i = -1, next = function next() {
          while (++i < iterable.length) {
            if (hasOwn.call(iterable, i)) {
              next.value = iterable[i];
              next.done = false;
              return next;
            }
          }

          next.value = undefined;
          next.done = true;

          return next;
        };

        return next.next = next;
      }
    }

    // Return an iterator with no values.
    return { next: doneResult };
  }
  runtime.values = values;

  function doneResult() {
    return { value: undefined, done: true };
  }

  Context.prototype = {
    constructor: Context,

    reset: function(skipTempReset) {
      this.prev = 0;
      this.next = 0;
      // Resetting context._sent for legacy support of Babel's
      // function.sent implementation.
      this.sent = this._sent = undefined;
      this.done = false;
      this.delegate = null;

      this.method = "next";
      this.arg = undefined;

      this.tryEntries.forEach(resetTryEntry);

      if (!skipTempReset) {
        for (var name in this) {
          // Not sure about the optimal order of these conditions:
          if (name.charAt(0) === "t" &&
              hasOwn.call(this, name) &&
              !isNaN(+name.slice(1))) {
            this[name] = undefined;
          }
        }
      }
    },

    stop: function() {
      this.done = true;

      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }

      return this.rval;
    },

    dispatchException: function(exception) {
      if (this.done) {
        throw exception;
      }

      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;

        if (caught) {
          // If the dispatched exception was caught by a catch block,
          // then let that catch block handle the exception normally.
          context.method = "next";
          context.arg = undefined;
        }

        return !! caught;
      }

      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;

        if (entry.tryLoc === "root") {
          // Exception thrown outside of any try block that could handle
          // it, so set the completion value of the entire function to
          // throw the exception.
          return handle("end");
        }

        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");

          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }

          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },

    abrupt: function(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev &&
            hasOwn.call(entry, "finallyLoc") &&
            this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }

      if (finallyEntry &&
          (type === "break" ||
           type === "continue") &&
          finallyEntry.tryLoc <= arg &&
          arg <= finallyEntry.finallyLoc) {
        // Ignore the finally entry if control is not jumping to a
        // location outside the try/catch block.
        finallyEntry = null;
      }

      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;

      if (finallyEntry) {
        this.method = "next";
        this.next = finallyEntry.finallyLoc;
        return ContinueSentinel;
      }

      return this.complete(record);
    },

    complete: function(record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }

      if (record.type === "break" ||
          record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = this.arg = record.arg;
        this.method = "return";
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }

      return ContinueSentinel;
    },

    finish: function(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },

    "catch": function(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }

      // The context.catch method must only be called with a location
      // argument that corresponds to a known catch block.
      throw new Error("illegal catch attempt");
    },

    delegateYield: function(iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      };

      if (this.method === "next") {
        // Deliberately forget the last sent value so that we don't
        // accidentally pass it on to the delegate.
        this.arg = undefined;
      }

      return ContinueSentinel;
    }
  };
})(
  // Among the various tricks for obtaining a reference to the global
  // object, this seems to be the most reliable technique that does not
  // use indirect eval (which violates Content Security Policy).
  typeof global === "object" ? global :
  typeof window === "object" ? window :
  typeof self === "object" ? self : this
);

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{}],74:[function(require,module,exports){
// ==UserScript==
// @name               iciba划词翻译
// @namespace          noe132.com
// @author             noe132
// @include            http://*
// @include            https://*
// @exclude            http://www.iciba.com*
// @grant              GM_xmlhttpRequest
// @grant              GM_addStyle
// @grant              GM_getValue
// @grant              GM_setValue
// @grant              GM_registerMenuCommand
// @icon               http://tb.himg.baidu.com/sys/portrait/item/d4346e6f65313332ac06
// @require            https://cdn.bootcss.com/es6-promise/4.1.1/es6-promise.auto.min.js
// @version            3.3.0
// @supportURL         http://tieba.baidu.com/f?kw=firefox
// ==/UserScript==


/* ------------------ changelog -------------------
 * update INFO:
 * update 2017/05/09 : bug fix
 * update 2017/04/20 : 添加鼠标悬浮触发查词
 * update 2017/04/19 : 终于搞明白怎么定位了
 * update 2017/04/18 : 添加最大选择数设置和默认行为设置，优化样式
 * update 2017/04/12 : 添加了百度翻译谷歌翻译按钮
 * update 2017/04/12 : 搞了个字符串压缩~解压字符串速度还可以
 * update 2017/04/11 : bug fix，重写鼠标事件定位方法
 * update 2017/03/24 : 添加鼠标事件10ms延迟
 * update 2017/03/24 : 用babel翻译async function，可以支持到chrome33
 * update 2017/03/23 : 使用百度翻译API，iciba的程序员不更新api
 * update 2016/12/23 : trim查询字符串，更新版本号到3
 * update 2016/09/23 : mouseClick只能左键触发
 * update 2016/08/19 : 不知为何connect属性未加上
 * update 2016/05/30 : 样式修改
 * update 2016/05/03 : 解释处理修改
 * update 2016/05/02 : 样式修改
 * update 2016/05/01 : 样式修改
 * update 2016/04/22 : 老版本浏览器兼容性修复
 * update 2016/04/17 : 样式修改
 * update 2016/04/17 : 重写
 * update 2016/04/09 : 样式小改
 * update 2016/03/27 : 紧急修复。。。
 * update 2016/03/16 : 样式修正
 * update 2016/03/05 : 样式小改
 * update 2015/07/31 : 貌似之前的wordpress判断不太给力，干脆带wp-admin的都干掉
 * update 2015/07/12 : 去除wp-admin/post.php页面，防止wordpress编辑文章自动添加div
 * update 2015/05/19 : 设置查词默认为小写
 * update 2015/05/09 : 按Ctrl可以使小蓝圈隐藏起来（暂时）
 * update 2015/01/03 : 样式全加了 !important 提高优先级
 * update 2014/12/24 : 添加设置选项（可当且仅当按住ctrl键显示翻译按钮）
 * update 2014/12/20 : 修正语法错误。。。
 * update 2014/12/19 : 搜词BUG修复，修正点击定位~
 * update 2014/12/10 : 严格模式'use strict'，提高性能
 * update 2014/12/04  : 贴吧图册预览修正
 * update 2014/11/16 : 更换mouseClick的触发条件为mouseup
 * update 2014/11/14 : 添加输入框查词，修正定位不正确。
 * ------------------------------------------------ */

'use strict';

var _promise = require('babel-runtime/core-js/promise');

var _promise2 = _interopRequireDefault(_promise);

var _from = require('babel-runtime/core-js/array/from');

var _from2 = _interopRequireDefault(_from);

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Iciba = function Iciba() {
  this.init();
};

Iciba.prototype.auto_active = 1; //没用~
Iciba.prototype.ctrlKey_actived = null;

// init 初始化对象 插入样式 读取设置 绑定事件
Iciba.prototype.init = function () {
  var _this = this;
  var style = '#icibaCirclePointer{font-family:"Microsoft Yahei",serif,sans-serif!important;display:block!important;z-index:10000!important;overflow:hidden!important;width:20px!important;height:20px!important;border:1px solid #555!important;border-radius:100px!important;background:#ABD!important;box-shadow:0 0 3px #111!important;opacity:.7!important;transition:.05s!important;box-sizing:border-box!important;-moz-box-sizing:border-box!important}#icibaCirclePointer:hover{opacity:1!important}#icibaCirclePointer:active{border:1px solid #353535!important;background:#90a2c4!important;box-shadow:0 0 3px #222!important}#icibaResultContainer{z-index:10000!important;width:auto!important;height:auto!important;max-width:320px!important;border:none!important;background:#EEE!important;box-shadow:0 0 8px 1px #999!important;letter-spacing:0!important}#icibaResultContainer *{box-sizing:border-box!important;-moz-box-sizing:border-box!important}#iciba_search_box{display:block!important;margin:0!important;padding:0!important;width:100%!important;border-bottom:1px solid #CCC!important;font-size:0!important;letter-spacing:0!important;word-spacing:0!important}#icibaResultContainer input{position:static!important;margin:0!important;border-radius:0!important;box-shadow:none!important;box-sizing:border-box!important;-moz-box-sizing:border-box!important;display:inline-block!important;vertical-align:middle!important;float:none!important}#iciba_search_box>#icibaSearchInput{padding:0 7px!important;width:calc(100% - 87px)!important;border:none!important;height:28px!important;line-height:28px!important;background:white!important;color:#666!important;font-size:14px!important;letter-spacing:0!important;font-family:"Microsoft Yahei",serif,sans-serif!important}#icibaSearchInput:hover,#icibaSearchInput:focus{box-shadow:0 0 3px 0 #CCC inset!important;color:#222!important}.icibaSearchButton{padding:0!important;width:29px!important;height:28px!important;border-radius:0!important;background-color:#EEE!important;background-repeat:no-repeat!important;border:none!important;border-left:1px solid #CCC!important}.icibaSearchButton:hover{background-color:#fafafa!important}.icibaSearchButton:active{background-color:#e5e5e5!important;box-shadow:0 0 2px #888 inset!important}#icibaSearchButton{background-image:url("data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJDYXBhXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IiB2aWV3Qm94PSIwIDAgNTYuOTY2IDU2Ljk2NiIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNTYuOTY2IDU2Ljk2NjsiIHhtbDpzcGFjZT0icHJlc2VydmUiPgogICAgPHBhdGgKICAgICAgICBkPSJNNTUuMTQ2LDUxLjg4N0w0MS41ODgsMzcuNzg2YzMuNDg2LTQuMTQ0LDUuMzk2LTkuMzU4LDUuMzk2LTE0Ljc4NmMwLTEyLjY4Mi0xMC4zMTgtMjMtMjMtMjNzLTIzLDEwLjMxOC0yMywyMyBzMTAuMzE4LDIzLDIzLDIzYzQuNzYxLDAsOS4yOTgtMS40MzYsMTMuMTc3LTQuMTYybDEzLjY2MSwxNC4yMDhjMC41NzEsMC41OTMsMS4zMzksMC45MiwyLjE2MiwwLjkyIGMwLjc3OSwwLDEuNTE4LTAuMjk3LDIuMDc5LTAuODM3QzU2LjI1NSw1NC45ODIsNTYuMjkzLDUzLjA4LDU1LjE0Niw1MS44ODd6IE0yMy45ODQsNmM5LjM3NCwwLDE3LDcuNjI2LDE3LDE3cy03LjYyNiwxNy0xNywxNyBzLTE3LTcuNjI2LTE3LTE3UzE0LjYxLDYsMjMuOTg0LDZ6IiBzdHlsZT0iZmlsbDogcmdiKDE4NywgMTg3LCAxODcpOyI+PC9wYXRoPgo8L3N2Zz4K")!important;background-position:center!important;background-size:15px 15px!important}#icibaSearchButtonTranslateGoogle{background-image:url("data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB2aWV3Qm94PSIwIDAgNzAgNzAiIHdpZHRoPSI3MCIgaGVpZ2h0PSI3MCI+CiAgICA8cGF0aAogICAgICAgIGZpbGw9IiM0Mjg1RjQiCiAgICAgICAgZD0iTTM1LjI5IDQxLjQxVjMySDY3Yy4zMSAxLjY0LjQ3IDMuNTguNDcgNS42OCAwIDcuMDYtMS45MyAxNS43OS04LjE1IDIyLjAxLTYuMDUgNi4zLTEzLjc4IDkuNjYtMjQuMDIgOS42NkMxNi4zMiA2OS4zNS4zNiA1My44OS4zNiAzNC45MS4zNiAxNS45MyAxNi4zMi40NyAzNS4zLjQ3YzEwLjUgMCAxNy45OCA0LjEyIDIzLjYgOS40OWwtNi42NCA2LjY0Yy00LjAzLTMuNzgtOS40OS02LjcyLTE2Ljk3LTYuNzItMTMuODYgMC0yNC43IDExLjE3LTI0LjcgMjUuMDMgMCAxMy44NiAxMC44NCAyNS4wMyAyNC43IDI1LjAzIDguOTkgMCAxNC4xMS0zLjYxIDE3LjM5LTYuODkgMi42Ni0yLjY2IDQuNDEtNi40NiA1LjEtMTEuNjVsLTIyLjQ5LjAxeiIvPgo8L3N2Zz4K")!important;background-size:15px 15px!important;background-position:center!important}#icibaSearchButtonTranslateBaidu{background-image:url("data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJDYXBhXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IiB3aWR0aD0iOTBweCIgaGVpZ2h0PSI5MHB4IiB2aWV3Qm94PSIwIDAgOTAgOTAiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDkwIDkwOyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+DQoJPHBhdGggaWQ9IkJhaWR1IiBkPSJNMjQuMDEyLDMzLjU4OGMwLjUzNSw3LjY1LTMuNjExLDE0LjE3My05LjI2NCwxNC41N0M5LjA5Nyw0OC41NTUsNC4wODEsNDIuNjc1LDMuNTQ2LDM1LjAyMyAgIGMtMC41MzUtNy42NSwzLjYxMS0xNC4xNzQsOS4yNjQtMTQuNTcxQzE4LjQ2MiwyMC4wNTYsMjMuNDc4LDI1LjkzNywyNC4wMTIsMzMuNTg4eiBNNjIuOTM4LDEuODc0ICAgYy01LjQ5MS0xLjQwMS0xMS40NzQsMy40ODktMTMuMzYyLDEwLjkyMWMtMS44OTUsNy40MzIsMS4wMjMsMTQuNTkyLDYuNTE0LDE1Ljk5M2M1LjQ5LDEuNCwxMS40NzYtMy40ODgsMTMuMzY1LTEwLjkyMSAgIEM3MS45MTQsOC4xOTQsNjQuMjUzLDIuMjA4LDYyLjkzOCwxLjg3NHogTTc1LjgxMiwyNi45MjVjLTUuNzc1LDAuMDg2LTEwLjM1OSw1LjU3OS0xMC4yMzIsMTQuMDg4ICAgYzAuMTI3LDguNTA4LDQuOTA0LDEyLjM4NywxMC42ODUsMTIuMzAxYzUuNzcyLTAuMDg2LDEwLjM1OC00LjEwMywxMC4yMzMtMTIuNjE0Qzg2LjMzLDI5LjYyNiw3Ny4xOTUsMjYuOTA1LDc1LjgxMiwyNi45MjV6ICAgIE0zMy45NjUsMGMtNS40OTYsMC05Ljk1MSw2LjE2LTkuOTUxLDEzLjc1NmMwLDcuNTk2LDQuNDU1LDEzLjc1Myw5Ljk1MSwxMy43NTNjNS40OTYsMCw5Ljk1Mi02LjE1Nyw5Ljk1Mi0xMy43NTMgICBDNDMuOTE3LDYuMTYsMzkuNDYxLDAsMzMuOTY1LDB6IE0zMi42OTMsNDIuNzJjLTMuMTc1LDQuNTYtNi43NzUsOS4wMTEtMTMuNzYyLDE0Ljg0M2MtNi45ODgsNS44MzItOS45NTIsOS44NTgtOS45NTIsMTUuNzk1ICAgYzAsNS45MzYsMy4zODgsMTUuNzk1LDEzLjAyMiwxNS43OTVjOS42MzQsMCwxNC4yOTItMi4xMjEsMjEuOTE1LTIuMTIxYzcuNjIzLDAsMTIuNzA3LDIuOTY5LDIyLjMzOSwyLjk2OSAgIGM5LjYzNSwwLDEzLjY1OC05LjExNywxMy42NTgtMTUuMDUzYzAtNS45MzctMS42NzItOS4yOTctOS4zOTEtMTYuMDcyYy00Ljk0NS00LjM0Ni05LjEzOC03Ljg4NS0xNS43MDItMTcuMDAyICAgYy0zLjI0NS00LjUwOC02Ljk4Ny01LjA4OC0xMC45MDQtNS4wODhDMzkuOTk5LDM2Ljc4NSwzNS44NywzOC4xNjMsMzIuNjkzLDQyLjcyeiIgc3R5bGU9ImZpbGw6IHJnYigzNSwgMzUsIDIyMCk7Ij48L3BhdGg+DQo8L3N2Zz4NCg==")!important;background-size:auto 15px!important;background-position:center!important}#icibaResultTextBox{margin:0!important;padding:10px 10px 0 10px!important;color:#222!important;text-align:left!important;font-size:14px!important;font-family:Arial,Helvetica,sans-serif!important;background:#fbfbfb!important;max-height:250px!important;overflow-x:hidden!important;overflow-y:auto!important}#icibaResultTextBox::after{content:""!important;display:block!important;background:transparent!important;height:10px!important}.icIBahyI-new_word{display:none!important}.icIBahyI-label_list>LABEL{display:inline!important}#icibaResultTextBox div,#icibaResultTextBox ul,#icibaResultTextBox li,#icibaResultTextBox p,#icibaResultTextBox form,#icibaResultTextBox input,#icibaResultTextBox label{margin:0!important;padding:0!important;font-weight:normal!important}#icibaResultTextBox input,#icibaResultTextBox button,#icibaResultTextBox textarea{font-weight:inherit!important;font-style:inherit!important;font-size:inherit!important;font-family:Arial,Helvetica,sans-serif!important}#icibaResultTextBox ul,#icibaResultTextBox li{list-style:none!important}#icibaResultTextBox a:focus{outline:none!important}#icibaResultTextBox img{border:0!important}#icibaResultTextBox strong{font-weight:100!important;font-family:"Segoe UI",Verdana,Lucida Sans Regular,Lucida Sans Unicode,Arial,sans-serif!important}#icibaResultTextBox .icIBahyI-dictbar{font-size:12px!important}#icibaResultTextBox .icIBahyI-register,#icibaResultTextBox .icIBahyI-right_bg,#icibaResultTextBox .icIBahyI-up,#icibaResultTextBox .icIBahyI-down{float:right!important}#icibaResultTextBox .icIBahyI-register{padding-left:25px!important}#icibaResultTextBox a.icIBahyI-text_black,#icibaResultTextBox .icIBahyI-nav_list strong{color:#333!important}#icibaResultTextBox a{color:#236fd4!important;text-decoration:underline!important}#icibaResultTextBox a:hover{color:#236fd4!important}#icibaResultTextBox .icIBahyI-handwrite,#icibaResultTextBox .icIBahyI-handwrite_over,#icibaResultTextBox .icIBahyI-drop_down{position:absolute!important;width:16px!important;height:16px!important;cursor:pointer!important}#icibaResultTextBox .icIBahyI-handwrite{top:14px!important;right:130px!important;background-position:0 -70px!important}#icibaResultTextBox .icIBahyI-handwrite_over{top:14px!important;right:130px!important;background-position:-18px -70px!important}#icibaResultTextBox #icIBahyI-dict_main{padding:0!important;text-align:left!important}#icibaResultTextBox .icIBahyI-dictbar{display:block!important;padding:0!important;height:auto!important;line-height:1.2!important}#icibaResultTextBox .icIBahyI-title{position:relative!important;padding:16px 17px 0 18px!important;color:#333!important;font-weight:bold!important;font-size:24px!important;font-family:arial,sans-serif!important;line-height:32px!important;word-break:break-all!important}#icibaResultTextBox .icIBahyI-dict_title{color:#333!important;font-weight:bold!important;font-family:arial,sans-serif!important}#icibaResultTextBox .icIBahyI-prons{display:block!important;padding:0!important;height:auto!important;white-space:normal!important;font-weight:700!important}#icibaResultTextBox .icIBahyI-dictbar .icIBahyI-fl{vertical-align:middle!important;font-size:12px!important;line-height:normal!important}#icibaResultTextBox .icIBahyI-dictbar .icIBahyI-fl *{font-size:12px!important}#icibaResultTextBox .icIBahyI-ico_sound{text-decoration:none!important;border:none!important;display:inline-block!important;overflow:hidden!important;margin:0!important;width:16px!important;height:16px!important;background:url("data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJDYXBhXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IiB2aWV3Qm94PSIwIDAgMjMyLjE1MyAyMzIuMTUzIiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCAyMzIuMTUzIDIzMi4xNTM7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4KCTxnIGlkPSJQbGF5Ij4KCQk8cGF0aAoJCQlzdHlsZT0iZmlsbC1ydWxlOiBldmVub2RkOyBjbGlwLXJ1bGU6IGV2ZW5vZGQ7IGZpbGw6IHJnYig4MCwgMTMwLCAyMjApOyIKCQkJZD0iTTIwMy43OTEsOTkuNjI4TDQ5LjMwNywyLjI5NGMtNC41NjctMi43MTktMTAuMjM4LTIuMjY2LTE0LjUyMS0yLjI2NiAgIGMtMTcuMTMyLDAtMTcuMDU2LDEzLjIyNy0xNy4wNTYsMTYuNTc4djE5OC45NGMwLDIuODMzLTAuMDc1LDE2LjU3OSwxNy4wNTYsMTYuNTc5YzQuMjgzLDAsOS45NTUsMC40NTEsMTQuNTIxLTIuMjY3ICAgbDE1NC40ODMtOTcuMzMzYzEyLjY4LTcuNTQ1LDEwLjQ4OS0xNi40NDksMTAuNDg5LTE2LjQ0OVMyMTYuNDcxLDEwNy4xNzIsMjAzLjc5MSw5OS42Mjh6Ij48L3BhdGg+Cgk8L2c+Cjwvc3ZnPgo=")!important;transition:0s!important;vertical-align:middle!important}#icibaResultTextBox .icIBahyI-ico_sound:hover{opacity:.7!important}#icibaResultTextBox .icIBahyI-ico_sound:active{opacity:.9!important}#icibaResultTextBox .icIBahyI-eg,#icibaResultTextBox .icIBahyI-us{padding-top:0!important;font-family:"lucida sans unicode",arial!important;display:block!important}#icibaResultTextBox .icIBahyI-new_word{float:left!important;padding-top:2px!important}#icibaResultTextBox .icIBahyI-new_word a{display:block!important;padding:3px 10px 0 20px!important;width:35px!important;height:17px!important;background-position:-274px 0!important;color:#999!important;font-weight:100!important;font-family:"Microsoft Yahei"!important}#icibaResultTextBox .icIBahyI-new_word a.icIBahyI-new_word2{background-position:-274px -19px!important}#icibaResultTextBox .icIBahyI-usually,#icibaResultTextBox .icIBahyI-prons{color:#666!important;font-weight:100!important}#icibaResultTextBox .icIBahyI-simple{margin:5px 0 5px 0!important}#icibaResultTextBox .icIBahyI-group_prons{clear:both!important;margin:0!important}#icibaResultTextBox .icIBahyI-group_prons .icIBahyI-second{float:none!important;padding-top:0!important}#icibaResultTextBox .icIBahyI-group_prons .icIBahyI-second .icIBahyI-eg{height:24px!important}#icibaResultTextBox .icIBahyI-group_pos{clear:both!important;overflow:hidden!important;color:#222!important;font-size:14px!important}#icibaResultTextBox .icIBahyI-group_pos *{font-size:14px!important}#icibaResultTextBox .icIBahyI-group_pos p:not(:last-of-type){margin-bottom:5px!important}#icibaResultTextBox .icIBahyI-label_list{float:left!important;padding-bottom:9px!important;width:87%!important;text-align:left!important}#icibaResultTextBox .icIBahyI-cn .icIBahyI-group_pos{color:#333!important}#icibaResultTextBox .icIBahyI-group_pos strong{color:#8d8d8d!important}#icibaResultTextBox .icIBahyI-margin_top{padding-top:6px!important}#icibaResultTextBox .icIBahyI-part_list a,#icibaResultTextBox .icIBahyI-tab_list li a,#icibaResultTextBox .icIBahyI-new_word a,#icibaResultTextBox .icIBahyI-part_main h3 a{text-decoration:none!important}#icibaResultTextBox .icIBahyI-tab_list{display:none!important}#icibaResultTextBox .icIBahyI-title{padding:13px 10px 1px!important;font-size:14px!important}#icibaResultTextBox .icIBahyI-group_pos{font-size:14px!important}#icibaResultTextBox .icIBahyI-group_pos .icIBahyI-fl{padding:0 6px 0 0!important;color:#999!important}#icibaResultTextBox .icIBahyI-group_pos span{vertical-align:baseline!important;line-height:normal!important;float:none!important;display:inline!important;padding:0!important}#icibaResultTextBox .icIBahyI-synon{color:#333!important;line-height:28px!important}#icibaResultTextBox .icIBahyI-suggest,#icibaResultTextBox .icIBahyI-suggest2{padding:0 0 3px 0!important;color:#333!important;word-wrap:break-word!important;font-size:14px!important;line-height:22px!important}#icibaResultTextBox .icIBahyI-suggest ul{padding:7px 0 4px!important;line-height:155%!important}#icibaResultTextBox .icIBahyI-suggest li{padding-left:14px!important;background-position:-134px -304px!important}#icibaResultTextBox .icIBahyI-suggest p{line-height:250%!important}#icibaResultTextBox .icIBahyI-suggest .icIBahyI-pr a{padding-right:3px!important}#icibaResultTextBox .icIBahyI-suggest p.icIBahyI-pr{margin-top:3px!important;line-height:18px!important}#icibaResultTextBox .icIBahyI-suggest .icIBahyI-pr a{display:inline-block!important;padding-right:10px!important}#icibaResultTextBox .icIBahyI-footer{padding:0!important;width:auto!important;color:#999!important;text-align:right!important;font-size:12px!important;line-height:18px!important}#icibaResultTextBox .icIBahyI-footer a{border:none!important;text-decoration:none!important;padding:0 3px 0 0!important;background:none!important;color:#236fd4!important;text-decoration:none!important;font-size:12px!important;line-height:18px!important}#icibaResultTextBox .icIBahyI-footer a:hover{color:#236fd4!important}#icibaResultTextBox .icIBahyI-text_blue{color:#236fd4!important}#icibaResultTextBox .icIBahyI-list li{padding:0 15px!important}#icibaResultTextBox .icIBahyI-li_dt,.icIBahyI-li_dd{display:inline!important;line-height:24px!important}#icibaResultTextBox .icIBahyI-li_dt{padding-right:5px!important;color:#232323!important}#icibaResultTextBox .icIBahyI-li_dd{color:#777!important}#ICIBA_TOO_LONG{padding-top:10px!important;padding-left:10px!important;font-size:12px!important}';
  GM_addStyle(style);
  GM_registerMenuCommand('iciba划词翻译设置(ctrl键查词设置)', function () {
    return _this.openSetting_ctrl();
  });
  GM_registerMenuCommand('iciba划词翻译设置(设置最大查词长度)', function () {
    return _this.openSetting_length();
  });
  GM_registerMenuCommand('iciba划词翻译设置(默认查词引擎)', function () {
    return _this.openSetting_default();
  });
  GM_registerMenuCommand('iciba划词翻译设置(小蓝圈查词行为)', function () {
    return _this.openSetting_click_or_over();
  });
  _this.loadSetting();
  _this.eventBinding();
};

// loadSetting 读取设置
Iciba.prototype.loadSetting = function () {
  // Ctrl键触发
  var _this = this;
  _this.ctrlKey_actived = parseInt(GM_getValue('ctrlKey_actived') || '0');
  _this.maxSelectlength = GM_getValue('maxSelectlength') || '150';
  _this.defaultBehavior = GM_getValue('defaultBehavior') || '0';
  _this.mouseoverRatherThanClick = GM_getValue('mouseoverRatherThanClick') || '0';
  GM_setValue('ctrlKey_actived', _this.ctrlKey_actived);
  GM_setValue('maxSelectlength', _this.maxSelectlength);
  GM_setValue('defaultBehavior', _this.defaultBehavior);
  GM_setValue('mouseoverRatherThanClick', _this.mouseoverRatherThanClick);
};

// eventBinding 绑定事件
Iciba.prototype.eventBinding = function () {
  var _this = this;
  window.addEventListener('mouseup', function (e) {
    setTimeout(function () {
      _this._mouseClick(e, _this);
    }, 10);
  }, false);
  window.addEventListener('keydown', function (e) {
    _this._keyDown(e, _this);
  }, false);
};

// openSetting_ctrl ctrl设置对话框
Iciba.prototype.openSetting_ctrl = function () {
  var _this = this;
  _this.ctrlKey_actived = confirm('按住ctrl键（当且仅当）开启翻译？') ? 1 : 0;
  GM_setValue('ctrlKey_actived', _this.ctrlKey_actived);
};

// openSetting_length 最大取词长度设置对话框
Iciba.prototype.openSetting_length = function () {
  var _this = this;
  var len = prompt('\u6700\u5927\u5212\u8BCD\u7FFB\u8BD1\u957F\u5EA6\uFF08\u7559\u7A7A\u4E3A\u9ED8\u8BA4\u503C150\u5B57\uFF0C\u5F53\u524D\u4E3A ' + _this.maxSelectlength + '\uFF09\uFF1F') || '150';
  try {
    len = parseInt(Number(len));
  } catch (e) {
    alert('输入数据无效，操作取消！');
    return;
  }
  var confirm_len = true;
  if (len < 10) {
    confirm_len = confirm('\u4F60\u786E\u5B9A\u8981\u8BBE\u7F6E\u4E00\u4E2A\u8FD9\u4E48\u5C0F\u7684\u6570\u503C(' + len + ')\uFF1F');
  }
  if (!confirm_len) {
    return;
  }
  _this.maxSelectlength = len;
  GM_setValue('maxSelectlength', _this.maxSelectlength);
};

// openSetting_default 默认行为设置对话框
Iciba.prototype.openSetting_default = function () {
  var _this = this;
  var behavior = prompt('\u70B9\u51FB\u84DD\u8272\u5C0F\u5706\u5708\u540E\u7684\u9ED8\u8BA4\u884C\u4E3A\uFF08\u8F93\u5165\u76F8\u5E94\u7684\u6570\u503C\uFF0C\u5F53\u524D\u4E3A ' + _this.defaultBehavior + '\uFF09\uFF1F(0:\u9ED8\u8BA4iciba\u5212\u8BCD\u7FFB\u8BD1 , 1:\u767E\u5EA6\u7FFB\u8BD1 , 2:\u8C37\u6B4C\u7FFB\u8BD1)\'') || '0';
  if (behavior === '0') {
    _this.defaultBehavior = '0';
  } else if (behavior === '1') {
    _this.defaultBehavior = '1';
  } else if (behavior === '2') {
    _this.defaultBehavior = '2';
  } else {
    alert('输入数据无效，操作取消！');
  }
  GM_setValue('defaultBehavior', _this.defaultBehavior);
};

// openSetting_ctrl ctrl设置对话框
Iciba.prototype.openSetting_click_or_over = function () {
  var _this = this;
  _this.mouseoverRatherThanClick = confirm('是否将「鼠标点击小蓝圈」 打开查词框行为改为「鼠标移至小蓝圈」打开查词框？') ? '1' : '0';
  GM_setValue('mouseoverRatherThanClick', _this.mouseoverRatherThanClick);
};

// showIcibaCirclePointer 显示并定位小圆点
Iciba.prototype.showIcibaCirclePointer = function (e) {
  var _this = this;

  var de = _this.getPosition(e);
  _this.icibaCirclePointer = document.createElement('div');
  _this.icibaCirclePointer.id = 'icibaCirclePointer';
  _this.icibaCirclePointer.style.position = 'absolute';
  _this.icibaCirclePointer.style.top = de.re.offsetTop + 7 + 'px';
  _this.icibaCirclePointer.style.left = de.re.offsetLeft + 5 + 'px';
  _this.icibaCirclePointer.setAttribute('keyword', window.getSelection().toString().toLowerCase().trim());

  var mouseoverTimout = 0;
  if (_this.mouseoverRatherThanClick === '1') {
    _this.icibaCirclePointer.addEventListener('mouseenter', function (e) {
      mouseoverTimout = setTimeout(function () {
        _this.showContainer(e, _this);
      }, 100); // 100ms delay prevents accident mouseover
    }, false);
    _this.icibaCirclePointer.addEventListener('mouseleave', function () {
      clearTimeout(mouseoverTimout);
    }, false);
  } else {
    _this.icibaCirclePointer.addEventListener('click', function (e) {
      _this.showContainer(e, _this);
    }, false);
  }

  document.body.appendChild(_this.icibaCirclePointer);
};

// removeCirclePointer 去除小圆点
Iciba.prototype.removeCirclePointer = function () {
  var _this = this;
  if (_this.icibaCirclePointer) {
    document.body.removeChild(_this.icibaCirclePointer);
  }
  _this.icibaCirclePointer = null;
};

// showContainer 显示并定位查词框
Iciba.prototype.showContainer = function (e, _this) {
  var word = _this.icibaCirclePointer.getAttribute('keyword');
  _this.removeCirclePointer();
  _this.createContainer(e);
  _this.containerLoadData(word, 'auto');

  // getData(word,e,bodyClientHeight,bodyClientWidth,windowinnerHeight,windowinnerWidth,htmlClientHeight,htmlClientWidth)
};

// createContainer 创建查词框
Iciba.prototype.createContainer = function (e) {
  var _this = this;

  _this.icibaResultContainer = document.createElement('div');
  _this.icibaResultContainer.id = 'icibaResultContainer';
  _this.icibaResultContainer.style.position = 'absolute';
  _this.icibaResultContainer.innerHTML = '\
    <div id="iciba_search_box">\
        <input id="icibaSearchInput" type="text" />\
        <input id="icibaSearchButtonTranslateBaidu" class="icibaSearchButton" type="button" />\
        <input id="icibaSearchButtonTranslateGoogle" class="icibaSearchButton" type="button" />\
        <input id="icibaSearchButton" class="icibaSearchButton" type="button" />\
    </div>\
    <div id="icibaResultTextBox"></div>';

  _this.icibaResultTextBox = _this.icibaResultContainer.querySelector('#icibaResultTextBox');
  _this.icibaSearchInput = _this.icibaResultContainer.querySelector('#icibaSearchInput');
  _this.icibaSearchButton = _this.icibaResultContainer.querySelector('#icibaSearchButton');
  _this.icibaSearchButtonTranslateBaidu = _this.icibaResultContainer.querySelector('#icibaSearchButtonTranslateBaidu');
  _this.icibaSearchButtonTranslateGoogle = _this.icibaResultContainer.querySelector('#icibaSearchButtonTranslateGoogle');

  // bind events
  _this.icibaSearchInput.addEventListener('keypress', function (e) {
    if (e.target === _this.icibaSearchInput) {
      if (e.keyCode != 13) {
        return;
      }
    }
    _this.containerLoadData(_this.icibaSearchInput.value, 'auto');
  }, false);
  _this.icibaSearchButton.addEventListener('click', function () {
    _this.containerLoadData(_this.icibaSearchInput.value, 'iciba');
  }, false);
  _this.icibaSearchButtonTranslateBaidu.addEventListener('click', function () {
    _this.containerLoadData(_this.icibaSearchInput.value, 'baidu');
  }, false);
  _this.icibaSearchButtonTranslateGoogle.addEventListener('click', function () {
    _this.containerLoadData(_this.icibaSearchInput.value, 'google');
  }, false);

  _this.containerSetPosition(e);
  document.body.appendChild(_this.icibaResultContainer);
};

// removeContainer 去除查词框
Iciba.prototype.removeContainer = function () {
  var _this = this;
  if (_this.icibaResultContainer) {
    document.body.removeChild(_this.icibaResultContainer);
    _this.icibaResultContainer = null;
    _this.icibaResultTextBox = null;
    _this.icibaSearchInput = null;
    _this.icibaSearchButton = null;
  }
};

// containerSetPosition 定位查词框
Iciba.prototype.containerSetPosition = function (e) {
  var _this = this;
  var de = _this.getPosition(e);
  if (de.re.detectHeight - de.re.offsetTop < 220 || de.window.innerHeight - e.clientY < 180) {
    // TODO using bottom position
    _this.icibaResultContainer.style.top = 'auto';
    _this.icibaResultContainer.style.bottom = de.re.positionHeight - de.re.offsetTop + 'px';
  } else {
    _this.icibaResultContainer.style.top = de.re.offsetTop + 'px';
    _this.icibaResultContainer.style.bottom = 'auto';
  }

  if (de.re.detectWidth - de.re.offsetLeft < 220 || de.window.innerWidth - e.clientY < 180) {
    // using right position
    _this.icibaResultContainer.style.left = 'auto';
    _this.icibaResultContainer.style.right = de.re.positionWidth - de.re.offsetLeft + 'px';
  } else {
    _this.icibaResultContainer.style.left = de.re.offsetLeft + 'px';
    _this.icibaResultContainer.style.right = 'auto';
  }
  _this.icibaResultContainer.style.display = '';
};

// containerLoadData 获取数据查词
Iciba.prototype.containerLoadData = function (word, engine) {
  var _this = this;
  _this.icibaResultTextBox.innerHTML = 'Loading......';
  _this.icibaSearchInput.value = word;
  engine = engine === 'auto' ? { 0: 'iciba', 1: 'baidu', 2: 'google' }[_this.defaultBehavior] : engine;
  var get_iciba_result = function () {
    var _ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee(word) {
      var result, text;
      return _regenerator2.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return got({
                method: 'GET',
                referer: 'http://www.iciba.com/',
                url: 'http://open.iciba.com/huaci/dict.php?word=' + word,
                timeout: 10000
              });

            case 2:
              result = _context.sent;
              text = result.replace(/\\/g, '');

              text = text.match(/dict\.innerHTML='(.*)'/)[1];
              text = text.replace(/icIBahyI-'ico_sound'/g, '"icIBahyI-ico_sound"');
              return _context.abrupt('return', text);

            case 7:
            case 'end':
              return _context.stop();
          }
        }
      }, _callee, this);
    }));

    return function get_iciba_result(_x) {
      return _ref.apply(this, arguments);
    };
  }();
  var get_lang_detect = function () {
    var _ref2 = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee2(word) {
      var formdata, lang_detect, result;
      return _regenerator2.default.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              formdata = new FormData();

              formdata.append('query', encodeURIComponent((0, _from2.default)(word).splice(0, 25).join('')));
              _context2.next = 4;
              return got({
                method: 'POST',
                referer: 'http://fanyi.baidu.com',
                url: 'http://fanyi.baidu.com/langdetect',
                data: formdata,
                timeout: 5000
              });

            case 4:
              lang_detect = _context2.sent;
              result = JSON.parse(lang_detect);

              if (!(result.error === 0)) {
                _context2.next = 10;
                break;
              }

              return _context2.abrupt('return', result.lan);

            case 10:
              throw new Error('翻译文本语言未知！');

            case 11:
            case 'end':
              return _context2.stop();
          }
        }
      }, _callee2, this);
    }));

    return function get_lang_detect(_x2) {
      return _ref2.apply(this, arguments);
    };
  }();
  var get_baidu_translation_result = function () {
    var _ref3 = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee3(lang_detect, target_lang, word) {
      var translation_formData, result;
      return _regenerator2.default.wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              translation_formData = new FormData();

              translation_formData.append('from', lang_detect);
              translation_formData.append('to', target_lang);
              translation_formData.append('query', word);
              translation_formData.append('transtype', 'translang');

              _context3.next = 7;
              return got({
                method: 'POST',
                referer: 'http://fanyi.baidu.com',
                url: 'http://fanyi.baidu.com/v2transapi',
                data: translation_formData,
                timeout: 5000
              });

            case 7:
              result = _context3.sent;


              result = JSON.parse(result);

              if (!(result.trans_result.type === 2 && result.trans_result.status === 0)) {
                _context3.next = 13;
                break;
              }

              return _context3.abrupt('return', result.trans_result.data[0].dst);

            case 13:
              throw new Error('翻译出错！');

            case 14:
            case 'end':
              return _context3.stop();
          }
        }
      }, _callee3, this);
    }));

    return function get_baidu_translation_result(_x3, _x4, _x5) {
      return _ref3.apply(this, arguments);
    };
  }();
  var get_google_translation_result = function () {
    var _ref4 = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee4(word) {
      var tl = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'zh-CN';
      var override = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
      var token, url, query_string, result;
      return _regenerator2.default.wrap(function _callee4$(_context4) {
        while (1) {
          switch (_context4.prev = _context4.next) {
            case 0:
              _context4.next = 2;
              return _this.get_google_translate_token(word);

            case 2:
              token = _context4.sent.value;
              url = 'https://translate.google.cn/translate_a/single?';
              query_string = 'client=t&sl=auto&tl=' + tl + '&hl=zh-CN&dt=at&dt=bd&dt=ex&dt=ld&dt=md&dt=qca&dt=rw&dt=rm&dt=ss&dt=t&ie=UTF-8&oe=UTF-8&source=btn&tk=' + token;
              _context4.next = 7;
              return got({
                method: 'POST',
                headers: {
                  'Referer': 'https://translate.google.cn/',
                  'Cache-Control': 'max-age=0',
                  'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
                  // 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36'
                },
                url: url + query_string,
                data: 'q=' + word,
                timeout: 5000
              });

            case 7:
              result = _context4.sent;

              result = JSON.parse(result);
              // detected language

              if (!(result[8][0][0] === 'zh-CN' && override === 0)) {
                _context4.next = 13;
                break;
              }

              return _context4.abrupt('return', get_google_translation_result(word, tl = 'en', 1));

            case 13:
              return _context4.abrupt('return', result[0].map(function (v) {
                return v[0] ? v[0] : '';
              }).join(''));

            case 14:
            case 'end':
              return _context4.stop();
          }
        }
      }, _callee4, this);
    }));

    return function get_google_translation_result(_x6) {
      return _ref4.apply(this, arguments);
    };
  }();

  var get_translation = function () {
    var _ref5 = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee5(word, engine) {
      var iciba_result, playbtn, i, lang_detect, target_lang, baidu_translation_result, google_translation_result;
      return _regenerator2.default.wrap(function _callee5$(_context5) {
        while (1) {
          switch (_context5.prev = _context5.next) {
            case 0:
              if (!(engine === 'iciba')) {
                _context5.next = 9;
                break;
              }

              _context5.next = 3;
              return get_iciba_result(word);

            case 3:
              iciba_result = _context5.sent;

              _this.icibaResultTextBox.innerHTML = iciba_result;
              playbtn = document.querySelectorAll('.icIBahyI-ico_sound');

              if (playbtn.length != 0) {
                for (i = 0; i < playbtn.length; i++) {
                  playbtn[i].setAttribute('mp3', playbtn[i].getAttribute('onclick').match(/asplay_hanci\('(.*)'\)/)[1]);
                  playbtn[i].removeAttribute('onclick');
                  playbtn[i].addEventListener('click', _this.playSound, false);
                }
              }
              _context5.next = 25;
              break;

            case 9:
              if (!(engine === 'baidu')) {
                _context5.next = 20;
                break;
              }

              _context5.next = 12;
              return get_lang_detect(word);

            case 12:
              lang_detect = _context5.sent;
              target_lang = lang_detect === 'zh' ? 'en' : 'zh';
              _context5.next = 16;
              return get_baidu_translation_result(lang_detect, target_lang, word);

            case 16:
              baidu_translation_result = _context5.sent;

              _this.icibaResultTextBox.innerHTML = baidu_translation_result;
              _context5.next = 25;
              break;

            case 20:
              if (!(engine === 'google')) {
                _context5.next = 25;
                break;
              }

              _context5.next = 23;
              return get_google_translation_result(word);

            case 23:
              google_translation_result = _context5.sent;

              _this.icibaResultTextBox.innerHTML = google_translation_result;

            case 25:
            case 'end':
              return _context5.stop();
          }
        }
      }, _callee5, this);
    }));

    return function get_translation(_x9, _x10) {
      return _ref5.apply(this, arguments);
    };
  }();

  get_translation(word, engine).catch(function (err) {
    _this.icibaResultTextBox.innerHTML = err.message;
  });
};

// https://github.com/matheuss/google-translate-token
// get_google_translate_token 获取google translate token
Iciba.prototype.get_google_translate_token = function (word) {
  window.TKK = GM_getValue('TKK') || '0';
  /* eslint-disable */
  // BEGIN
  function sM(a) {
    var b;
    if (null !== yr) b = yr;else {
      b = wr(String.fromCharCode(84));
      var c = wr(String.fromCharCode(75));
      b = [b(), b()];
      b[1] = c();
      b = (yr = window[b.join(c())] || "") || "";
    }
    var d = wr(String.fromCharCode(116)),
        c = wr(String.fromCharCode(107)),
        d = [d(), d()];
    d[1] = c();
    c = "&" + d.join("") + "=";
    d = b.split(".");
    b = Number(d[0]) || 0;
    for (var e = [], f = 0, g = 0; g < a.length; g++) {
      var l = a.charCodeAt(g);
      128 > l ? e[f++] = l : (2048 > l ? e[f++] = l >> 6 | 192 : (55296 == (l & 64512) && g + 1 < a.length && 56320 == (a.charCodeAt(g + 1) & 64512) ? (l = 65536 + ((l & 1023) << 10) + (a.charCodeAt(++g) & 1023), e[f++] = l >> 18 | 240, e[f++] = l >> 12 & 63 | 128) : e[f++] = l >> 12 | 224, e[f++] = l >> 6 & 63 | 128), e[f++] = l & 63 | 128);
    }
    a = b;
    for (f = 0; f < e.length; f++) {
      a += e[f], a = xr(a, "+-a^+6");
    }a = xr(a, "+-3^+b+-f");
    a ^= Number(d[1]) || 0;
    0 > a && (a = (a & 2147483647) + 2147483648);
    a %= 1E6;
    return c + (a.toString() + "." + (a ^ b));
  }

  var yr = null;
  var wr = function wr(a) {
    return function () {
      return a;
    };
  },
      xr = function xr(a, b) {
    for (var c = 0; c < b.length - 2; c += 3) {
      var d = b.charAt(c + 2),
          d = "a" <= d ? d.charCodeAt(0) - 87 : Number(d),
          d = "+" == b.charAt(c + 1) ? a >>> d : a << d;
      a = "+" == b.charAt(c) ? a + d & 4294967295 : a ^ d;
    }
    return a;
  };

  // END
  /* eslint-enable */

  function updateTKK() {
    return new _promise2.default(function (resolve, reject) {
      var now = Math.floor(Date.now() / 3600000);
      if (Number(window.TKK.split('.')[0]) === now) {
        resolve();
      } else {
        got({
          method: 'GET',
          url: 'https://translate.google.cn/',
          timeout: 5000
        }).then(function (result) {
          var code = result.match(/TKK=(.*?)\(\)\)'\);/g);
          if (code) {
            eval(code[0]);
            /* eslint-disable no-undef */
            if (typeof TKK !== 'undefined') {
              window.TKK = TKK;
              GM_setValue('TKK', TKK);
            }
            /* eslint-enable no-undef */
          }
          resolve();
        }).catch(function () {
          reject();
        });
      }
    });
  }

  function get(text) {
    return updateTKK().then(function () {
      var tk = sM(text);
      tk = tk.replace('&tk=', '');
      return { name: 'tk', value: tk };
    }).catch(function (err) {
      throw err;
    });
  }
  return get(word);
};

// conflictsResolve 不同网站的冲突解决
Iciba.prototype.conflictsResolve = function () {
  if (window.location.href.indexOf('http://tieba.baidu.com/photo/p?kw=') === 1) {
    GM_addStyle('.af_container{position:relative;}');
  }
};

// playSound 发声
Iciba.prototype.playSound = function (e) {
  var audio = document.createElement('audio');
  var source = document.createElement('source');
  source.type = 'audio/mpeg';
  source.src = e.target.getAttribute('mp3');
  source.autoplay = 'autoplay';
  source.controls = 'controls';
  audio.appendChild(source);
  audio.play();
};

// getPosition 计算鼠标事件对于元素应去的top left值
Iciba.prototype.getPosition = function (e) {
  // e.clienX e.clientY 是相对于浏览器viewport的位置（当前窗口）
  // e.pageX e.pageY 是相对于当前页面的位置（页面最左上角，不考虑 margin）
  // position:absolute 以父元素content-box的左上角定位
  // html 和 body 都为 static 时用 以当前 viewport 的大小的隐形元素 最上面定位 （不考虑 html body margin）
  // html 不为 static 时用 html 的 content-box 定位
  // body 不为 static 时用 body 的 content-box 定位
  // html 和 body 似乎不会发生margin-collapse
  // margin collapse 只发生在 margin-top 和 margin-bottom
  var de = {
    page: {
      offsetTop: e.pageY,
      offsetLeft: e.pageX
    },
    body: {
      rect: document.body.getBoundingClientRect(),
      scrollHeight: document.body.scrollHeight, // inner height of an element in pixels, including padding but not the horizontal scrollbar
      scrollWidth: document.body.scrollWidth, // inner width of an element in pixels. It includes padding but not the vertical scrollbar
      clientTop: document.body.clientTop, // top border width
      clientLeft: document.body.clientLeft, // left border width
      position: document.defaultView.getComputedStyle(document.body)['position']

    },
    html: {
      rect: document.documentElement.getBoundingClientRect(), // coordinates relative to the viewport origin, of the top of the rectangle box
      scrollHeight: document.documentElement.scrollHeight, // inner height of an element in pixels, including padding but not the horizontal scrollbar
      scrollWidth: document.documentElement.scrollWidth, // inner width of an element in pixels. It includes padding but not the vertical scrollbar
      clientTop: document.documentElement.clientTop, // top border width
      clientLeft: document.documentElement.clientLeft, // left border width
      position: document.defaultView.getComputedStyle(document.documentElement)['position']
    },
    window: {
      scrollY: window.scrollY, // number of pixels that the document has already been scrolled vertically.
      scrollX: window.scrollX, // number of pixels that the document has already been scrolled horizontally.
      innerHeight: window.innerHeight, // viewport height
      innerWidth: window.innerWidth // viewport width
    },
    e: e,
    base: 'page',
    get re() {
      return this[this.base];
    }
  };

  de.page.positionHeight = de.window.innerHeight;
  de.page.positionWidth = de.window.innerWidth;
  de.page.detectHeight = de.html.scrollHeight;
  de.page.detectWidth = de.html.scrollHeight;

  de.body.positionHeight = de.body.scrollHeight;
  de.body.positionWidth = de.body.scrollWidth;
  de.body.detectHeight = de.body.scrollHeight;
  de.body.detectWidth = de.body.scrollWidth;

  de.html.positionHeight = de.html.scrollHeight;
  de.html.positionWidth = de.html.scrollWidth;
  de.html.detectHeight = de.html.scrollHeight;
  de.html.detectWidth = de.html.scrollWidth;

  // formula from jquery.offset
  de.body.offsetTop = e.pageY - (de.body.rect.top + de.window.scrollY + de.body.clientTop);
  de.body.offsetLeft = e.pageX - (de.body.rect.left + de.window.scrollX + de.body.clientLeft);
  de.html.offsetTop = e.pageY - (de.html.rect.top + de.window.scrollY + de.html.clientTop);
  de.html.offsetLeft = e.pageX - (de.html.rect.left + de.window.scrollX + de.html.clientLeft);

  if (de.html.position !== 'static') {
    de.base = 'html';
  } else if (de.body.position !== 'static') {
    de.base = 'body';
  }
  return de;
};

// _keyDown keydown 事件处理函数
Iciba.prototype._keyDown = function (e, _this) {
  if (e.key === 'Control' && e.keyCode === 17) {
    if (!_this.ctrlKey_actived) {
      _this.removeCirclePointer();
    }
  }
};

// _isInsideOf 判断是否在内部
Iciba.prototype._isInsideOf = function (e, target) {
  // when target is not exist
  if (!target) {
    return false;
  }
  var e_target = e.target;
  while (e_target != target && e_target) {
    e_target = e_target.parentNode;
  }
  if (e_target === target) {
    return true;
  } else {
    return false;
  }
};

// _mouseClick mousedown 事件处理函数
Iciba.prototype._mouseClick = function (e, _this) {
  // console.log('pageX:' + e.pageX + ',pageY:' + e.pageY + ',clientX:' + e.clientX + ',clientY:' + e.clientY)
  // ignore when click on icibaCirclePointer

  if (e.target.id === 'icibaCirclePointer') {
    return;
  }

  if (e.button != 0) {
    return;
  }

  // ignore when click insideof icibaResultContainer
  if (_this._isInsideOf(e, _this.icibaResultContainer)) {
    return;
  }

  // Ctrl键触发
  if (_this.ctrlKey_actived) {
    if (!(e.ctrlKey === true && e.shiftKey === false && e.altKey === false)) {
      _this.removeCirclePointer();
      _this.removeContainer();
      return;
    }
  }

  // remove all things
  if (_this.icibaResultContainer) {
    _this.removeContainer();
  }
  if (_this.icibaCirclePointer) {
    _this.removeCirclePointer();
  }

  // 显示iciba_icon
  if (window.getSelection().toString().length >= _this.maxSelectlength) {
    return; // ignore when selection is too loing
  }

  if (window.getSelection().toString().length !== 0) {
    _this.showIcibaCirclePointer(e);
    return;
  }

  // 去除iciba_icon
  if (window.getSelection().toString().length === 0) {
    _this.removeCirclePointer();
  }

  return;
};

function got(param) {
  return new _promise2.default(function (rs, rj) {
    var obj = {
      method: 'GET',
      referer: '',
      url: '',
      timeout: 10000,
      ontimeout: function ontimeout() {
        rj(new Error('网络超时！'));
      },
      onerror: function onerror() {
        rj(new Error('网络错误！'));
      },
      onload: function onload(response) {
        if (response.status != 200) {
          rj(new Error('网络错误！'));
        }
        rs(response.responseText);
      }
    };
    for (var x in param) {
      obj[x] = param[x];
    }
    GM_xmlhttpRequest(obj);
  });
}

{
  new Iciba();
}

},{"babel-runtime/core-js/array/from":1,"babel-runtime/core-js/promise":2,"babel-runtime/helpers/asyncToGenerator":3,"babel-runtime/regenerator":4}]},{},[74]);
