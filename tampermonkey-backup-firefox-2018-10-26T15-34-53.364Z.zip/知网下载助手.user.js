// ==UserScript==
// @name         知网下载助手
// @namespace    wyn665817@163.com
// @version      1.0.0
// @description  论文搜索结果页面和硕博论文详述页面的caj格式下载链接替换为pdf格式下载链接
// @author       wyn665817
// @match        *://*.cnki.net/*
// @include      *://*.cnki.net.*
// @include      *://*/cnki.net/*
// @run-at       document-end
// @grant        unsafeWindow
// @license      MIT
// ==/UserScript==

var $ = unsafeWindow.$,
url = location.pathname,
dbcode = ['CDFD', 'CMFD'];

if (url.endsWith('brief.aspx')) {
    var arr = new Array();
    $('.fz14').each(function() {
        arr.push(getQueryString('dbcode', this.href));
    });
    $('.briefDl_D, .briefDl_Y').each(function(index) {
        this.href = this.href.includes('&dflag') ? this.href.replace('&dflag=nhdown', '&dflag=pdfdown') : (this.href + '&dflag=pdfdown');
        if (dbcode.includes(arr[index])) {
            this.href = this.href.replace('kns', 'gb.oversea').replace('kns', 'kcms');
        }
    });
} else if (url.endsWith('detail.aspx') && dbcode.includes(getQueryString('dbcode', location.search))) {
    $('.dllink > .icon').each(function() {
        url = $(this).text().trim();
        if (url == '整本下载') {
            this.href = this.href.replace('&dflag=nhdown', '&dflag=pdfdown');
        } else if (url == '分页下载' || url == '分章下载') {
            this.href += '&cflag=pdf';
        } else {
            return true;
        }
        this.href = this.href.replace('kns', 'gb.oversea').replace('kns', 'kcms');
    });
}

function getQueryString(name, url) {
    var reg = new RegExp('(^|&|\\?)' + name + '=([^&]*)(&|$)', 'i'),
    r = url.match(reg);
    if (r != null) return decodeURI(r[2]); return null;
}